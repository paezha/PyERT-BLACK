"""
Tool Name:    GIS-Based Map Matching Algorithm
Source Name:  map_matching_algorithm.py
Version:      ArcGIS 10.0 or later
Author:       Ron Dalumpines (turugban@yahoo.com)
Requirements: Python 2.6 or later
Date Created: April 24, 2010
Last Revised: September 20, 2016
Description:  This tool matches GPS points with the road network.
"""

# Import module
from map_matching_algorithm_arcgis10i8 import *
  
# User-defined parameters.
#inFolder = r'P:\office_files\phd_dissertation\mapmatching\work\scripts\map-matching_darren\map-matching_shared_v2.0\data\gps_trajectory'
#inNetworkDataset = r'P:\office_files\phd_research_data\network_database\NAD83\CanMapRL\CAN_GD.gdb\CAN_ND\CAN_ND'
#outFolder = r'P:\office_files\phd_dissertation\mapmatching\work\scratch\map-matching_test\test_output\mm_output03'
#coordsys = r'P:\office_files\phd_dissertation\mapmatching\work\scripts\map-matching_darren\map-matching_shared_v2.0\data\projected_coordinated_system\NAD_1983_UTM_Zone_20N.prj'
#maxDistGap = 500
#maxIter = 10
#minDistBuf = 50
#maxDistBuf = 500
#incDistBuf = 50
#saveLogFile = False

inFolder = gp.GetParameterAsText(0)  # input folder containing GPS trajectories
inNetworkDataset = gp.GetParameterAsText(1)  # network dataset
outFolder = gp.GetParameterAsText(2)
coordsys = gp.GetParameterAsText(3)  # projected coordinate system (e.g., NAD 1983 UTM Zone 20N for STAR datasets)
maxDistGap = int(gp.GetParameterAsText(4))  # acceptable distance gap (in meters) within a trajectory
maxIter = int(gp.GetParameterAsText(5))  # number of attempts to relocate origin/destination to solve
minDistBuf = int(gp.GetParameterAsText(6))
maxDistBuf = int(gp.GetParameterAsText(7))
incDistBuf = int(gp.GetParameterAsText(8))
saveLogFile = gp.GetParameterAsText(9)

# Create the output folder.
if not gp.Exists(outFolder):
    os.mkdir(outFolder)
else:
    shutil.rmtree(outFolder)
    os.mkdir(outFolder)

# Get the folder for metadata geoprocessing history.
gis_version = gp.GetInstallInfo()["Version"]
gplogfolder = rs.get_folder(os.getenv("APPDATA"), ("Desktop%s;ArcToolbox;History" % gis_version))

# List metadata geoprocessing history files that should not be deleted.
donot_remove_list = []  # clear up geoprocessing history folder

try:
    fpath = os.path.join(outFolder, "map-matching.log")  # log IDs of GPS data processed
    with open(fpath, "w") as logFile:
        main(inFolder, inNetworkDataset, outFolder, coordsys, maxDistGap, maxIter, minDistBuf, maxDistBuf, incDistBuf, logFile)
    if not saveLogFile and gp.Exists(fpath): os.remove(fpath)
except:
    os.remove(fpath)
    gp.AddError("\nNot successful in map-matching GPS trajectories.")
    gp.AddError(traceback.format_exc())  # traceback info
finally:
    rs.delete_files(gplogfolder, donot_remove_list, file_patterns="*.xml")  # delete metadata geoprocessing history
    gp.AddMessage("\nDeleted metadata geoprocessing history.")
    del gp; sys.exit()  # make sure all files are released (unlocked)
