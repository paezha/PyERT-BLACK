"""
Tool Name:    GIS-Based Map Matching Algorithm
Source Name:  map_matching_algorithm_arcgis10i8.py
Version:      ArcGIS 10.0 and later
Author:       Ron Dalumpines (turugban@yahoo.com)
Requirements: Python 2.6 or later
Date Created: April 24, 2010
Last Revised: August 9, 2016
Description:  This tool matches GPS points with the road network.

Version History:
2012-05-02 (map_matching_algorithm_arcgis10i4.py)

2016-06-28 (map_matching_algorithm_arcgis10i5.py)

2016-07-05 (map_matching_algorithm_arcgis10i6.py)

2016-07-05 (map_matching_algorithm_arcgis10i7.py)

2016-08-09 (map_matching_algorithm_arcgis10i8.py)

"""

# Import modules
import sys
import os
import string
import arcgisscripting
import time
import shutil
import tempfile
import re
import traceback
import math

import route_solver as rs
import rca_utils as rca

# Create the geoprocessor object
gp = arcgisscripting.create()

# Set the necessary product code
gp.SetProduct("ArcInfo")

# Check out any necessary licenses
gp.CheckOutExtension("Network")

# Overwrite the output
gp.OverWriteOutput = True

def main(inFolder, inNetworkDataset, outFolder, coordsys, maxDistGap, maxIter, minDistBuf, maxDistBuf, incDistBuf, logFile):
    
    # Set the input workspace.
    gp.Workspace = inFolder
    gp.AddMessage("\nWorkspace: %s" % gp.Workspace)
    
    # Set the scratch folder or temporary working directory.
    gp.ScratchWorkspace = rs.get_scratch_folder(prefix="mm_temp_")
    gp.SetProgressorLabel("Set scratch workspace to %s ..." % gp.ScratchWorkspace)
    gp.AddMessage("Scratch Workspace: %s" % gp.ScratchWorkspace)
    
    # Set the projected coordinate system for the road network.
    gp.SetProgressorLabel("Set the projected coordinate system for the road network ...")
    spatialRef = rs.get_spatial_reference(coordsys)
    gp.AddMessage("Projected coordinate system: %s" % spatialRef.Name)
    
    # Get junction layer to count intersections.
    gp.SetProgressorLabel("Get junction layer to count intersections ...")
    junction_layer = rs.get_junction_layer(inNetworkDataset)
    
    gp.SetProgressorLabel("List GPS trajectories for processing ...")
    routeList = []
    for inputfile in rs.all_files(gp.Workspace, patterns="*.shp"):
        routeList.append(inputfile)
        #gp.AddMessage(inputfile)
    
    # Determine the number of input routes.    
    inputCount = len(routeList)
    gp.AddMessage("Total number of GPS trajectories: %i" % inputCount)
    
    # Process each route to extract attribute information.
    gp.SetProgressor("step", "Running map-matching algorithm ...", 0, inputCount, 1)
    
    # Set counter for map-matched routes.
    outputCount = 0
    
    # Write header on log file.
    logFile.write("route_name, gps_points, trajectory_length_meters, processing_time_seconds, error_message\n")
    logFile.flush()
    
    for route in routeList:
        
        startTime = time.clock()  # initialize timer to check the running time
        
        fc = os.path.basename(route)
        outRoutes = os.path.join(outFolder, fc)
        gp.AddMessage("\nMap-matching GPS trajectory: %s..." % fc)
        
        # Count the number of GPS points within the trajectory.
        gpsPoints = gp.GetCount(fc)

        try:
            gp.SetProgressorLabel("Trying to map-match GPS trajectory to digital network ...")
            
            mm = rs.RouteSolver2(inNetworkDataset, route, coordsys, maxDistGap, maxIter, minDistBuf, maxDistBuf, incDistBuf)
            
            gp.AddMessage("\nattrImpedance = %s" % mm.attrImpedance)
            gp.AddMessage("maxDistGap = %i Meters" % mm.maxDistGap)
            gp.AddMessage("maxIter = %i Attempts" % mm.IterateLimit)
            gp.AddMessage("minDistBuf = %s" % mm.distBuffer)
            gp.AddMessage("maxDistBuf = %i Meters" % mm.maxDistBuffer)
            gp.AddMessage("incDistBuf = %i Meters" % mm.distIncrement)
            
            # Get length of GPS trajectory (after transforming points into line).       
            tracLength = rs.get_trajectory_length(mm.noGapTrajectory)
            gp.AddMessage("\nLength of GPS trajectory: %.1f meters" % tracLength)
            
            mm.get_mapmatch_route(withBarriers=True)
            
            #print "outSolveTime:", mm.outSolveTime, "seconds"
            
            # Get straightline distance in meters.
            crowDist = mm.get_straightline_distance()
            gp.AddMessage("Straightline distance: %1.2f meters" % crowDist)
            
            # Count the number of turns.
            p = rca.ParserDirectionsXML2(mm.outNALayer)
            leftTurns = p.countLeftTurn
            rightTurns = p.countRightTurn
            sharpLeft = p.countSharpLeft
            sharpRight = p.countSharpRight
            totalTurns = p.countAllTurns
            gp.AddMessage("Extracted number of turns:\n\tleft turns: %s\n\tright turns: %s\n\tsharp left: %s\n\tsharp right: %s\n\ttotal turns: %s"
                          % (leftTurns, rightTurns, sharpLeft, sharpRight, totalTurns))
            
            # Get number of route segments, distance, time, and longest segment.
            numSeg, uniqSeg = p.count_segments(), p.count_unique_segments()
            longLegName, longLegDist = p.get_longleg_attribute("name"), p.get_longleg_attribute("distance")
            totTime, totDist = p.get_total_time(), p.get_total_distance()
            gp.AddMessage("Extracted following parameters from directions file:")
            gp.AddMessage("\tlongest leg name: %s\n\tlongest leg distance: %.1f meters" % (longLegName, longLegDist))
            gp.AddMessage("\tnumber of segments: %s\n\tnumber of unique segments: %s" % (numSeg, uniqSeg))
            gp.AddMessage("\ttotal route length: %.1f meters" % totDist)
            gp.AddMessage("\ttotal route time: %.1f minutes" % totTime)
            
            # Calculate route directness index (loop factor).
            try:
                ndxRouteDirect = totDist / crowDist  # route distance over straightline distance
            except ZeroDivisionError:
                ndxRouteDirect = 0  # very short segment
            except:
                raise
            gp.AddMessage("Route directness index: %.1f" % ndxRouteDirect)
            
            # Count the number of intersections (crossings)
            try:
                numXing = rca.count_stops(junction_layer, mm.outRoutesSubLayer)
            except TypeError:  # get_intersections() returns None
                numXing = 0
            gp.AddMessage("Number of intersections: %i" % numXing)
            
            # Get the average route distance between intersections (in meters).
            try:
                distPerXing = totDist/numXing
            except ZeroDivisionError:
                distPerXing = 0
            gp.AddMessage("Average route distance between intersections: %1.2f meters" % distPerXing)
            
        except Exception, err:
            gp.AddWarning(traceback.format_exc())
            logFile.write("%s, %i, 0, 0, %s\n" % (fc, gpsPoints, err.message))
            logFile.flush()
            gp.SetProgressorPosition()
            continue
        
        # Store the route generated if its length (or distance) meets threshold values.
        if (totDist > 0 and  # minimum route length
            totDist < tracLength*2):  # discard route that far exceeds GPS trajectory length
            
            # Copy generated route to output folder
            gp.CopyFeatures_management(mm.outRoutesSubLayer, outRoutes)
            gp.AddMessage("Generated route copied to output folder.")
            
            # Delete fieldnames no longer needed but leave one fieldname to avoid error
            gp.DeleteField_management(outRoutes, "FirstStopI;LastStopID;StopCount;Total_Minu;Total_Mete")
            gp.AddMessage("Unnecessary fieldnames deleted.")

            # Add fields for additional attributes
            gp.AddField_management(outRoutes, "route_name", "TEXT")  # route name (e.g. respondent ID on the GPS input filename)
            gp.AddField_management(outRoutes, "distance_m", "DOUBLE")  # travel distance in meters (based on Network Dataset)
            gp.AddField_management(outRoutes, "time_min", "DOUBLE")  # travel time in minutes (based on Network Dataset)
            gp.AddField_management(outRoutes, "crowdist_m", "DOUBLE")  # straightline distance between origin and destination
            gp.AddField_management(outRoutes, "traclen_m", "DOUBLE")  # length of GPS trajectory after transforming points into line (meters)
            gp.AddField_management(outRoutes, "num_roads", "SHORT")  # number of unique road segments identified by road names
            gp.AddField_management(outRoutes, "l_turns", "SHORT")  # number of left turns
            gp.AddField_management(outRoutes, "r_turns", "SHORT")  # number of right turns
            gp.AddField_management(outRoutes, "sl_turns", "SHORT")  # number of sharp left turns
            gp.AddField_management(outRoutes, "sr_turns", "SHORT")  # number of sharp right turns
            gp.AddField_management(outRoutes, "t_turns", "SHORT")  # number of total turns
            gp.AddField_management(outRoutes, "rdi", "FLOAT")  # route directness index (loop factor)
            gp.AddField_management(outRoutes, "crossings", "SHORT")  # number of intersections
            gp.AddField_management(outRoutes, "distxing", "DOUBLE")  # average route distance between intersections
            gp.AddField_management(outRoutes, "longleg_nm", "TEXT")  # road name of longest leg
            gp.AddField_management(outRoutes, "longleg_dm", "DOUBLE")  # length of longest leg (meters)
            gp.AddMessage("Added new fields for additional attributes.")

            # Remove ".shp" extension from input filename if shapefile
            try:
                fcName = string.split(fc, ".")[0]
            except Exception, err:
                gp.AddError(err.message)

            # Update the attribute fields
            rows = gp.UpdateCursor(outRoutes)
            row = rows.Next()
            while row:
                row.SetValue("route_name", fcName)
                row.SetValue("distance_m", totDist)
                row.SetValue("time_min", totTime)
                row.SetValue("crowdist_m", crowDist)
                row.SetValue("traclen_m", tracLength)
                row.SetValue("num_roads", uniqSeg)
                row.SetValue("l_turns", leftTurns)
                row.SetValue("r_turns", rightTurns)
                row.SetValue("sl_turns", sharpLeft)
                row.SetValue("sr_turns", sharpRight)
                row.SetValue("t_turns", totalTurns)
                row.SetValue("rdi", ndxRouteDirect)
                row.SetValue("crossings", numXing)
                row.SetValue("distxing", distPerXing)
                row.SetValue("longleg_nm", longLegName)
                row.SetValue("longleg_dm", longLegDist)
                rows.UpdateRow(row)
                row = rows.Next()
            del rows, row
            gp.AddMessage("Attribute field values updated.")

            # Delete the fieldname that cannot be removed earlier
            gp.DeleteField_management(outRoutes, "Name")
            
            outputCount += 1
            
        else:  # route travel distance does not meet the threshold values
            stopTime = time.clock()
            elapTime = stopTime - startTime
            error_message = "route length is zero or far exceeds the GPS trajectory length"
            gp.AddWarning("No route generated: %s" % error_message)
            logFile.write("%s, %i, %1.2f, %1.5f, %s\n" % (fc, gpsPoints, tracLength, elapTime, error_message))
            logFile.flush()
            gp.SetProgressorPosition()
            continue
        
        # Check the running time for the processed route
        stopTime = time.clock()
        elapTime = stopTime - startTime
        gp.AddMessage("Processing time: " + str(round(elapTime, 5)) + " seconds")
        
        logFile.write("%s, %i, %1.2f, %1.5f, none\n" % (fc, gpsPoints, tracLength, elapTime))
        logFile.flush()
        gp.SetProgressorPosition()
    
    gp.AddMessage("\nSuccessully map-matched %i of %i GPS trajectories." % (outputCount, inputCount))

if __name__ == '__main__':
    
    # User-defined parameters.
    inFolder = gp.GetParameterAsText(0)  # input folder containing GPS trajectories
    inNetworkDataset = gp.GetParameterAsText(1)  # network dataset
    outFolder = gp.GetParameterAsText(2)
    coordsys = gp.GetParameterAsText(3)  # projected coordinate system (e.g., NAD 1983 UTM Zone 20N for STAR datasets)
    maxDistGap = int(gp.GetParameterAsText(4))  # acceptable distance gap (in meters) within a trajectory
    maxIter = int(gp.GetParameterAsText(5))  # number of attempts to relocate origin/destination to solve
    minDistBuf = int(gp.GetParameterAsText(6))
    maxDistBuf = int(gp.GetParameterAsText(7))
    incDistBuf = int(gp.GetParameterAsText(8))
    saveLogFile = gp.GetParameterAsText(9)
    
    #inFolder = r'P:\office_files\phd_dissertation\mapmatching\work\scripts\map-matching_darren\map-matching_shared_v2.0\data\gps_trajectory'
    #inNetworkDataset = r'P:\office_files\phd_research_data\network_database\NAD83\CanMapRL\CAN_GD.gdb\CAN_ND\CAN_ND'
    #outFolder = r'P:\office_files\phd_dissertation\mapmatching\work\scratch\map-matching_test\test_output\mm_output03'
    #coordsys = r'P:\office_files\phd_dissertation\mapmatching\work\scripts\map-matching_darren\map-matching_shared_v2.0\data\projected_coordinated_system\NAD_1983_UTM_Zone_20N.prj'
    #maxDistGap = 500
    #maxIter = 10
    #minDistBuf = 50
    #maxDistBuf = 500
    #incDistBuf = 50
    #saveLogFile = False
    
    # Create the output folder.
    if not gp.Exists(outFolder):
        os.mkdir(outFolder)
    else:
        shutil.rmtree(outFolder)
        os.mkdir(outFolder)
    
    # Get the folder for metadata geoprocessing history.
    gis_version = gp.GetInstallInfo()["Version"]
    gplogfolder = rs.get_folder(os.getenv("APPDATA"), ("Desktop%s;ArcToolbox;History" % gis_version))
    
    # List metadata geoprocessing history files that should not be deleted.
    donot_remove_list = []  # clear up geoprocessing history folder
    
    try:
        fpath = os.path.join(outFolder, "map-matching.log")  # log IDs of GPS data processed
        with open(fpath, "w") as logFile:
            main(inFolder, inNetworkDataset, outFolder, coordsys, maxDistGap, maxIter, minDistBuf, maxDistBuf, incDistBuf, logFile)
        if not saveLogFile and gp.Exists(fpath): os.remove(fpath)
    except:
        os.remove(fpath)
        gp.AddError("\nNot successful in map-matching GPS trajectories.")
        gp.AddError(traceback.format_exc())  # traceback info
    finally:
        rs.delete_files(gplogfolder, donot_remove_list, file_patterns="*.xml")  # delete metadata geoprocessing history
        gp.AddMessage("\nDeleted metadata geoprocessing history.")
        del gp; sys.exit()  # make sure all files are released (unlocked)
