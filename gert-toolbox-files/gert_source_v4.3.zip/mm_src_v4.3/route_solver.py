"""
Tool Name: Route Solver (engine for map-matching and trip reconstruction algorithms)
Source Name: route_solver.py
Version:      ArcGIS 10.0 or 10.1, ArcInfo license
              (NOTE: can be used in 9.3 but needs retesting for the latest revision)
Creator: Ron Dalumpines (turugban@yahoo.com)
Requirements: Python 2.6 or later
Date Created: June 2, 2011
Last Revised: August 6, 2013
Description: Implements a class used to generate map-matched route or shortest path from GPS trajectory. A GPS trajectory
             consists of streams of points recorded by a GPS device that captures movement at a given period. This tool also
             includes methods often used when dealing with simple feature classes, particularly route layers.

Version History:
2013-08-06 (route_solver.py)

2016-06-29 (route_solver.py)
- updated RouteSolver class to expose max_gap
"""

# Imports.
import sys
import os
import time
import arcpy  # for methods in ArcGIS 10.0 or later
import arcgisscripting

from gert_utils import *

# Create the geoprocessor object.
gp = arcgisscripting.create(9.3)  # allow backward compatibility down to ArcGIS 9.3

# Set the necessary product code.
gp.SetProduct("ArcInfo")

# Check out any necessary licenses.
gp.CheckOutExtension("Network")

# Set geoprocessor to overwrite output.
gp.OverwriteOutput = True

class RouteSolver:
    """
    Class used to generate the shortest path or map-matched route from GPS trajectory.
    
    Routes generated can be a route layer or a line shapefile. The map-matched or observed route
    is the actual route taken by a mobile object (animal, person, or vehicle) along a road network.
    Impedance attribute must be in the list of network dataset attributes.
    """
    def __init__(self, inNetworkDataset, inStops, spatialReference, impedance="Minutes", lineField=None, sortField=None, maxDistGap=50000):
        self.inNetworkDataset = inNetworkDataset  # network dataset
        self.inStops = self.__get_trajectory(inStops)  # input GPS trajectory (point shapefile)
        self.__nd_attributes__ = get_nd_attributes(inNetworkDataset)  # list of network dataset attributes (used to verify impedance)
        self.attrImpedance = self.__get_valid_impedance__(impedance) # impedance used to solve for the route ("Meters" or "Minutes")
        self.inputBarriers = None  # network analysis object for line barriers
        self.withBarriers = False  # if solving for shortest path; set to True if solving for observed or map-matched route
        self.lineField = lineField  # field used to label each line (group of points) when converting GPS trajectory to line
        self.sortField = sortField  # field used to sort points in GPS trajectory before converting to line
        self.getTime = True  # include processing time in a returned tuple; set to False otherwise
        self.loopBarriers=None  # point barriers used in solving colocated origin/destination points
        
        self.distBuffer = "50 Meters"  # buffer distance in meters
        self.distIncrement = 25  # increment for buffer distance to find the right distance to solve successfully
        self.maxDistBuffer = 1000  # maximum buffer distance; no more attempts beyond this threshold
        
        self.IterateLimit = 25  # number of attempts to relocate origin/destination to solve
        self.NumStep = 1  # number of GPS points to step back to find valid origin/destination points
        self.naStopsFeatureLayer = "Stops"  # network analysis class for stops
        self.startOID = 0  # default index for origin point
        self.endOID = -1  # default index for destination point
        
        self.outNALayer = None  # network analysis layer (composite layer)
        self.outRoutesSubLayer = None  # map-matched route layer, a sublayer of network analysis layer
        self.outSolveTime = None  # processing time for map-matching a GPS trajectory
        self.outNewODLayer = None  # feature layer for origin and destination points
        
        self.outPointBarriers = None  # shortest path between origin and destination converted as points (used to solve colocated origin/destination points)

        self.snapEndPoints = None  # valid origin and destination points, snapped to road network

        self.spatialReference = self.get_spatial_reference(spatialReference)  # projected coordinate system of GPS trajectory
        
        self.maxDistGap = maxDistGap  # acceptable distance gap (in meters) within a trajectory
        
        #print "\nrepair gaps in GPS trajectory..."
        self.noGapTrajectory = get_nogap_trajectory_fast(inNetworkDataset, inStops, self.sortField, self.maxDistGap, impedance=self.attrImpedance,
                                                         spatial_reference=self.spatialReference)  # GPS trajectory with no gaps (projected)
    
    def __get_route_vertices(self):
        """
        Return map-matched route as points.
        """
        if self.outRoutesSubLayer is None:
            raise Exception("route does not exists to generate vertices")
        else:
            try:
                route_vertices = os.path.join("in_memory", "route_vertices")
                gp.FeatureVerticesToPoints_management(self.outRoutesSubLayer, route_vertices, "BOTH_ENDS")
            except:
                raise Exception("failed to generate the route vertices")
            else:
                return route_vertices
    
    def __get_od_coordinates(self):
        """
        Returns lat, lon coordinates for origin and destination points that are projected.
        
        @fcLayer = point feature class (projected)
        @origin = first record
        @destination = last record
        """
        # Select origin and destination points
        fcLayer = self.__get_route_vertices()
        select_odpoints2(fcLayer, locType='both_od')
        
        # Get coordinates
        try:
            desc = gp.Describe(fcLayer)
            rows = gp.SearchCursor(fcLayer, "", self.spatialReference, "", desc.OIDFieldName)
            row = rows.Next()
            origin_xy = True
            while row:
                pnt = row.shape.getpart()
                lat = pnt.y
                lon = pnt.x
                if origin_xy:
                    origLat = lat
                    origLon = lon
                    origin_xy = False
                else:
                    destLat = lat
                    destLon = lon
                row = rows.Next()
            return origLat, origLon, destLat, destLon
        except:
            raise
        finally:
            del rows, row, origin_xy
            clear_selection(fcLayer)
    
    def get_straightline_distance(self):
        y1, x1, y2, x2 = self.__get_od_coordinates()
        return get_straightline_distance(x1, y1, x2, y2)

    def __get_valid_impedance__(self, impedance):
        """
        Return a valid impedance attribute based on network dataset attributes.
        """
        if is_valid_impedance(impedance, self.__nd_attributes__):
            return impedance
        else:
            raise Exception("invalid value for impedance attribute, the network dataset should have that attribute or change the impedance")
    
    def __get_trajectory(self, infc):
        """
        Return a GPS trajectory if it has a coordinate system.
        """
        if has_coordsystem(infc):
            return infc
        else:
            raise Exception("input GPS trajectory must have a coordinate system")
        
    def delete(self):
        """
        Delete temporary objects associated with instantiated class.
        """
        delete_featureclass(self.inputBarriers, self.loopBarriers, self.outNALayer, self.outNewODLayer, self.snapEndPoints)
    
    def get_spatial_reference(self, spatialReference):
        """
        Return the spatial reference object for projected coordinate system of the GPS trajectory.
        """
        return get_spatial_reference(spatialReference)
    
    def __solve(self):
        """
        Solve the route based on GPS trajectory.
        """
        try:
            self.outNALayer, self.outRoutesSubLayer, self.outSolveTime = get_mapmatch_route_with_loop(self.inNetworkDataset, self.outNewODLayer,
                                                                                                      self.noGapTrajectory, self.attrImpedance,
                                                                                                      self.inputBarriers, self.lineField,
                                                                                                      self.sortField, self.distBuffer)
            pointbarriers = "%s\%s" % (self.outNALayer, "Point Barriers")
            if get_count_records(pointbarriers): self.outPointBarriers = pointbarriers
            #print "solve success!\n"
        except Exception, err:
            #print err.args
            pass
    
    def get_snap_points(self):
        """
        Return valid origin and destination points, snapped to the road network.
        """
        #print "\nget endpoints of shortest path (snap to road network)..."
        # Get the shortest path (routes) layer without barriers.
        self.get_shortest_path()
        if self.outRoutesSubLayer is None:
            raise Exception("cannot snap endpoints because no shortest path was generated")
        else:
            #sp_endpoints = get_featureclass_name(gp.workspace, "_sp_endpoints")
            sp_endpoints = os.path.join("in_memory", "_sp_endpoints")
            delete_featureclass(sp_endpoints)  # delete if exists
            gp.FeatureVerticesToPoints_management(self.outRoutesSubLayer, sp_endpoints, "BOTH_ENDS")
            #print "snap endpoints: %s" % sp_endpoints
            return sp_endpoints

    def __clean_up(self):
        """
        Delete temporary layers and reset pointers to None.
        """
        delete_featureclass(self.outNewODLayer)
        delete_featureclass(self.outNALayer)  # includes self.outRoutesSubLayer
        delete_featureclass(self.inputBarriers)
        self.outNewODLayer = None
        self.outNALayer = None
        self.outRoutesSubLayer = None
        self.outSolveTime = None
        self.inputBarriers = None

    def __final_match(self, impedance, return_line_only=False):
        """
        Private method that return the map-matched route based on GPS trajectory.
        """
        # Update required arguments.
        if impedance != "#":
            self.attrImpedance = self.__get_valid_impedance__(impedance) # set impedance used to solve route
        self.snapEndPoints = self.get_snap_points() # get endpoints of shortest path, snapped to road network

        # Reset values to None.
        delete_featureclass(self.outNALayer)  # remove "RouteLayer"
        self.outNewODLayer = None
        self.outNALayer = None

        # Get input barriers based on nogap trajectory.
        if self.withBarriers:
            self.inputBarriers = get_barriers(self.noGapTrajectory, self.lineField, self.sortField, self.distBuffer)
        else:
            raise Exception("need to specify barriers to solve for map-match route")
        
        # Get shortest path with barriers.
        for x in xrange(1, self.IterateLimit + 1, 1):
            #print "\nfinal_match: attempt %s solving now..." % x
            if self.outNewODLayer is None:  # first attempt to solve
                self.outNewODLayer = get_unique_layer(self.noGapTrajectory)  # starting OD locations
                self.__solve()
                if self.outNALayer is None:
                    delete_featureclass(self.outNewODLayer)
                    self.outNewODLayer = get_unique_layer(self.snapEndPoints)
                    continue
                else:
                    break
            else:  # next attempt: snap OD stops then solve again
                #print "origin/destination: %s \tbuffer distance: %s" % (self.outNewODLayer, self.distBuffer)
                self.inputBarriers = get_barriers(self.noGapTrajectory, self.lineField, self.sortField, self.distBuffer)
                self.__solve()
                if self.outNALayer is None:  # if first attempt failed, increase buffer distance
                    distValue = float(self.distBuffer.strip().split(" ")[0]) + self.distIncrement
                    distUnit = self.distBuffer.strip().split(" ")[1]
                    self.distBuffer = "%1.0f %s" % (distValue, distUnit)
                    if round(distValue) > self.maxDistBuffer:
                        self.__clean_up()
                        #print "check: the value of self.outNewODLayer is %s" % self.outNewODLayer
                        raise Exception("cannot generate the map-match route (distance buffer exceeds the threshold of %s meters)" % self.maxDistBuffer)
                    continue
                else:
                    break
        
        #print "\nend of iteration: %s attempts\n" % x
        #print self.outNewODLayer
        if self.outNALayer is None:
            raise Exception("Failed to generate map-match route.")
        
        if return_line_only:
            outfc = get_featureclass_name(gp.workspace, "route_solver_mapmatch_route")
            gp.copyfeatures_management(self.outRoutesSubLayer, outfc)
            self.__clean_up()
            return outfc
        else:
            return self.outNALayer, self.outRoutesSubLayer, self.outSolveTime
        
    def get_mapmatch_route(self, withBarriers=False, impedance="#", return_line_only=False):
        """
        Return the map-matched route based on GPS trajectory.
        """
        self.withBarriers = withBarriers
        if self.withBarriers:
            self.__final_match(impedance, return_line_only)
        else:
            self.get_shortest_path(impedance, return_line_only)
    
    def get_shortest_path(self, impedance="#", return_line_only=False):
        """
        Return the shortest path based on GPS trajectory.
        
        The shortest path generated can be according to travel time (impedance="Minutes") or
        travel distance (impedance="Meters").
        """
        if impedance != "#":
            self.attrImpedance = self.__get_valid_impedance__(impedance)
        delete_featureclass(self.outNALayer)  # remove "RouteLayer"
        self.outNewODLayer = None
        self.outNALayer = None
        self.startOID = 0; self.endOID = -1
        for x in xrange(1, self.IterateLimit + 1, 1):
            #print "shortest_path: attempt %s solving now ..." % x
            if self.outNewODLayer is None:  # first attempt to solve
                self.outNewODLayer = get_unique_layer(self.noGapTrajectory)  # starting OD locations
                self.__solve()
            else:  # next attempt: relocate OD stops then solve again
                self.__relocate_od_location()
                #print self.outNewODLayer
                self.__solve()
            if self.outNALayer is None:
                delete_featureclass(self.outNewODLayer)
                continue
            else:
                break
        
        #print "\nend of iteration: %s attempts\n" % x
        #print self.outNewODLayer
        if self.outNALayer is None:
            raise Exception("Failed to generate map-match route.")

        if return_line_only:
            outfc = get_featureclass_name(gp.workspace, "route_solver_shortest_path")
            gp.copyfeatures_management(self.outRoutesSubLayer, outfc)
            self.__clean_up()
            return outfc
        else:
            return self.outNALayer, self.outRoutesSubLayer, self.outSolveTime
    
    def __relocate_od_location(self):
        """
        Relocate origin and destination points.
        
        Used to find valid origin and destination points to solve for the route based on GPS trajectory.
        """
        self.outNewODLayer, self.startOID, self.endOID = get_relocated_odlayer(self.noGapTrajectory, (self.startOID,self.endOID),
                                                                               self.NumStep, self.naStopsFeatureLayer)

class RouteSolver2(RouteSolver):
    def __init__(self, inNetworkDataset, inStops, spatialReference, maxDistGap, maxIter, minDistBuf, maxDistBuf, incDistBuf, impedance="Minutes", lineField=None, sortField=None):
        RouteSolver.__init__(self, inNetworkDataset, inStops, spatialReference, impedance=impedance, lineField=lineField, sortField=sortField, maxDistGap=maxDistGap)
        self.IterateLimit = maxIter
        self.distBuffer = "%i Meters" % minDistBuf
        self.maxDistBuffer = maxDistBuf
        self.distIncrement = incDistBuf
        
def get_mapmatch_route(inNetworkDataset, inStops, attrImpedance="Minutes", inputBarriers=None, sortField=None, getTime=True, loopBarriers=None):
    """
    Return a tuple of network analysis layer and map-matched routes sublayer (NALayer, routesSubLayer, {solveTime}).
    {} optional
    
    The map-matched route is defined by input route endpoints and point barriers.
    Solution uses shortest path and other tools from the Network Analyst extension in ArcGIS.
    Originally developed for ArcGIS 9.3 with ArcInfo license.

    Parameters:
    @inNetworkDataset = network dataset
    @inStops = origin and destination points <- feature class or layer
    @attrImpedance = attribute impedance [Minutes, Meters] <- string
    @inputBarriers = barriers <- feature class or layer
    @sortField = name of the field to sort inStops <- string
    @getTime = set to include solving time in the tuple to
                track performance [True, False] <- boolean
    """
    #print "run map-matching ..."
    solveStart = time.clock()
    try:
        # Create the route analysis layer.
        try:
            in_network_dataset = inNetworkDataset
            out_network_analysis_layer = "RouteLayer"
            impedance_attribute = attrImpedance
            find_best_order = "USE_INPUT_ORDER"
            ordering_type = "PRESERVE_BOTH"
            time_windows = "NO_TIMEWINDOWS"
            accumulate_attribute_name = "Minutes;Meters"
            UTurn_policy = "ALLOW_UTURNS"
            restriction_attribute_name = ""
            hierarchy = "NO_HIERARCHY"
            hierarchy_settings = ""
            output_path_shape = "TRUE_LINES_WITH_MEASURES"
            start_date_time = ""
            gp.MakeRouteLayer_na(inNetworkDataset,
                                 out_network_analysis_layer,
                                 impedance_attribute,
                                 find_best_order,
                                 ordering_type,
                                 time_windows,
                                 accumulate_attribute_name,
                                 UTurn_policy,
                                 restriction_attribute_name,
                                 hierarchy,
                                 hierarchy_settings,
                                 output_path_shape,
                                 start_date_time)
        except Exception, err:
            raise Exception("failed to create route analysis layer: %s" % err.args)
        
        # Load stops (origin and destination).
        try:
            if get_count_records(inStops) == 2:
                inStopsLayer = get_unique_layer(inStops)
            else:
                inStopsLayer = select_odpoints(inStops, sortField)  # endpoints
            #print "\tload stop locations ..."
            gp.AddLocations_na(out_network_analysis_layer, "Stops", inStopsLayer, snap_to_position_along_network="SNAP")
        except Exception, err:
            delete_featureclass(out_network_analysis_layer)
            raise Exception("failed to add stops to route analysis layer: %s" % err.args)
        
        # Load barriers (point, line, or polygon).
        #print "\tload input barriers ..."
        try:
            load_barriers(out_network_analysis_layer, inputBarriers)  # ensure that route generated is inside buffer zone for potential road links
            if loopBarriers:
                load_barriers(out_network_analysis_layer, loopBarriers)  # avoid wrong result in case origin and destination are located closely
            else:
                pass
        except Exception, err:
            delete_featureclass(out_network_analysis_layer, inStopsLayer)
            raise Exception("failed to add barriers to route analysis layer: %s" % err.args)
        
        # Solve for the map-matched route.
        #print "\tsolve for shortest path ..."
        try:
            gp.Solve_na(out_network_analysis_layer, "SKIP")
        except Exception, err:
            delete_featureclass(out_network_analysis_layer, inStopsLayer)
            raise Exception("failed to generate the map-matched route")
            #raise Exception("failed to generate the map-matched route: %s" % err.args)
        else:
            solveEnd = time.clock()
            solveTime = solveEnd - solveStart
            NALayer, routesSubLayer = out_network_analysis_layer, "Routes"
    except:
        raise
    else:
        delete_featureclass(inStopsLayer)
        if not getTime:
            return NALayer, routesSubLayer
        else:
            return NALayer, routesSubLayer, solveTime

def get_shortest_path(inNetworkDataset, inStops, attrImpedance="Minutes"):
    """
    Return the shortest path between two points as a line feature class.
    """
    NALayer, routesSubLayer, solveTime = get_mapmatch_route(inNetworkDataset, inStops, attrImpedance)
    shortest_path = get_featureclass_name(gp.workspace, "_shortest_path")
    gp.copyfeatures_management(routesSubLayer, shortest_path)
    delete_featureclass(NALayer)
    return shortest_path

def get_mapmatch_route_with_loop(inNetworkDataset, inStops, nogapGPSTrack, attrImpedance, inputBarriers, lineField=None,
                                 sortField=None, distBuff="50 meters"):
    """
    Return a tuple (outNALayer, mapRoutes, solveTime) result of map-matching that considers colocated origin/destination locations.
    """
    # Determine the distance gap threshold if two points are considered too close.
    linear_unit = gp.Describe(nogapGPSTrack).SpatialReference.LinearUnitName.lower()
    gpsTrackLength = get_trajectory_length(nogapGPSTrack, lineField, sortField)
    if gpsTrackLength == 0:
        raise Exception("impossible to generate route: GPS trajectory length is zero")
    gap_threshold = min(round(0.5*gpsTrackLength), 500)  # 1/2 trajectory length but no more than 500 meters
    #print "gap threshold if colocated: %s %ss" % (gap_threshold, linear_unit)
    
    # Avoid loop barriers if origin and destination are closely located.
    gap_meters = get_od_distance(nogapGPSTrack)  # distance between origin and destination
    #print "distance between origin and destination: %s %ss" % (gap_meters, linear_unit)
    if is_colocated(nogapGPSTrack, gap_threshold, gap_meters):
        #print "colocated ..."
        # Relocate origin if origin/destination have exactly the same locations.
        if gap_meters == 0:
            #print "origin/destination locations are exactly the same ..."
            split_colocated_points(inStops, moveby=1, spatial_reference="")
        # Create point barriers to prevent loop.
        loopBarriers = get_avoid_loop_barriers(inNetworkDataset, nogapGPSTrack, attrImpedance)
        # Iterate until route is solved.
        loopBarriersLayer = get_unique_layer(loopBarriers)
        fidlist = list_oids(loopBarriersLayer)
        fidname = gp.describe(loopBarriersLayer).oidfieldname
        #print "number of loopbarriers: %s" % len(fidlist)
        for fid in fidlist:
            expression = '"%s" = %s' % (fidname, fid)
            gp.selectlayerbyattribute_management(loopBarriersLayer, "NEW_SELECTION", expression)
            try:
                outNALayer, mapRoutes, solveTime = get_mapmatch_route(inNetworkDataset, inStops, attrImpedance, inputBarriers,
                                                                      sortField, getTime=True, loopBarriers=loopBarriersLayer)
                break
            except:
                continue
        else:
            delete_featureclass(loopBarriersLayer, loopBarriers)
            raise Exception("tried all loop barriers and failed to solve route")
        # Delete intermediate data.
        delete_featureclass(loopBarriersLayer, loopBarriers)
    # Otherwise, perform map-matching without the loop barriers.
    else:
        #print "not colocated ..."
        outNALayer, mapRoutes, solveTime = get_mapmatch_route(inNetworkDataset, inStops, attrImpedance, inputBarriers,
                                                              sortField, getTime=True, loopBarriers=None)
    return outNALayer, mapRoutes, solveTime

def get_avoid_loop_barriers(inNetworkDataset, inStops, attrImpedance="Minutes"):
    """
    Return the midpoints of shortest path links between origin and destination (OD).
    These points are used to prevent map-matching to fail when OD points are very closely located (colocated).

    Inputs:
    @inNetworkDataset = network dataset
    @inStops = origin and destination (OD) points
    @attrImpedance = shortest path based on distance ("Meters") or time ("Minutes")
    """
    # Get shortest path (line) between origin and destination.
    shortestpath = get_shortest_path(inNetworkDataset, inStops, attrImpedance)
    # Split line at vertices.
    splitpath = get_featureclass_name(gp.workspace, "_splitpath")
    gp.SplitLine_management(shortestpath, splitpath)
    # Convert split line to points.
    #loopBarriers = get_featureclass_name(gp.workspace, "_loopbarriers")
    loopBarriers = os.path.join("in_memory", "_loopbarriers")
    gp.FeatureToPoint_management(splitpath, loopBarriers, "INSIDE")
    # Delete intermediate data.
    delete_featureclass(shortestpath, splitpath)
    return loopBarriers

def get_nogap_trajectory(networkdataset, trajectory, sortfield, max_gap=100, impedance="Minutes"):
    """
    Return a copy of GPS trajectory with no wide gaps.

    Inputs:
    @networkdataset = network dataset
    @trajectory = sequence of GPS points (GPS trajectory)
    @sortfield = fieldname used to sort GPS records
    @max_gap = acceptable distance gap between two points (in meters)
    @impedance = shortest path based on distance ("Meters") or time ("Minutes")
    """
    start = True
    fidlist = []
    oid = gp.describe(trajectory).oidfieldname
    infclayer = get_unique_layer(trajectory)
    #startpoint = get_featureclass_name(gp.workspace, "_startpoint")
    startpoint = os.path.join("in_memory", "_startpoint")
    #endpoint = get_featureclass_name(gp.workspace, "_endpoint")
    endpoint = os.path.join("in_memory", "__endpoint")
    
    #nogap = get_featureclass_name(gp.workspace, "_nogap")
    nogap = os.path.join("in_memory", "_nogap")
    if gp.exists(nogap):
        gp.delete_management(nogap) # prevent appending vertices to existing file
        #print "deleted existing nogap trajectory file: %s" % nogap
    
    rows = gp.searchcursor(trajectory, "", "", "", sortfield)
    row = rows.next()
    while row:
        fid = row.getvalue(oid)
        fidlist.append(fid)
        expression = '"%s" = %s' % (oid, fid)
        gp.selectlayerbyattribute_management(infclayer, "NEW_SELECTION", expression)
        if start:
            gp.copyfeatures_management(infclayer, startpoint)
            start = False
        else:
            gp.copyfeatures_management(infclayer, endpoint)
            # Get the distance between two points.
            pointdist = get_point_distance(startpoint, endpoint, radius="100 Kilometers")
            # Insert vertices between points with a wide gap.
            if pointdist > max_gap:
                fidlist.pop()  # remove last feature ID
                append_gap_vertices(fidlist, trajectory, nogap)
                gap_vertices = get_gap_vertices(networkdataset, impedance, startpoint, endpoint)
                gp.append_management(gap_vertices, nogap, "NO_TEST", "#", "#")
                delete_featureclass(gap_vertices)
                fidlist = [fid]
            else:
                pass
            gp.copyfeatures_management(infclayer, startpoint)
        row = rows.next()
    del rows, row
    append_gap_vertices(fidlist, trajectory, nogap)
    # Delete intermediate data.
    delete_featureclass(infclayer, startpoint, endpoint)
    return nogap

def get_nogap_trajectory_fast(networkdataset, trajectory, sortfield, max_gap=100, impedance="Minutes", spatial_reference=""):
    """
    Return a copy of GPS trajectory with no wide gaps.

    Inputs:
    @networkdataset = network dataset
    @trajectory = sequence of GPS points (GPS trajectory)
    @sortfield = fieldname used to sort GPS records
    @max_gap = acceptable distance gap between two points (in meters)
    @impedance = shortest path based on distance ("Meters") or time ("Minutes")
    @spatial_reference = spatial reference
    """
    # Check if input is projected or can be projected.
    check_if_canbeprojected(trajectory, spatial_reference)
    
    nogap = get_new_featureclass("_nogap", "POINT", spatial_reference, is_temporary=True)
    icur = gp.insertcursor(nogap, spatial_reference)

    start = True
    shapename = gp.describe(trajectory).shapefieldname
    rows = gp.searchcursor(trajectory, "", spatial_reference, "", sortfield)
    row = rows.next()
    while row:
        pt = row.getvalue(shapename).getpart(0)
        x2, y2 = pt.X, pt.Y
        
        if start:
            x1, y1 = x2, y2
            start = False
        else:
            # Get the distance between two successive points.
            pointdist = get_straightline_distance(x1, y1, x2, y2)
            #print "distance between two successive points: %.1f" % pointdist
            #print "max_gap: %.1f" % max_gap
            
            # Insert vertices between points with a wide gap.
            if pointdist > max_gap:
                # Get origin and destination of the gap.
                coordlist = [[x1, y1], [x2, y2]]
                odstops = get_points_from_coordinates(coordlist, spatial_reference)
                # Get shortest path vertices within the gap.
                gap_vertices = get_gap_vertices(networkdataset, impedance, odstops)
                # Insert vertices to final output.
                scur = gp.searchcursor(gap_vertices)
                srow = scur.next()
                while srow:
                    icur.insertrow(srow)
                    srow = scur.next()
                del scur, srow
                #print "inserted gap vertices to %s" % nogap
                
                delete_featureclass(odstops, gap_vertices)
            else:
                pass
        icur.insertrow(row)
        x1, y1 = x2, y2
        row = rows.next()
    del rows, row, icur
    return nogap

def get_gap_vertices(networkdataset, impedance, *odstops):
    """
    Return a point feature class to fill-in the gap between two points.

    Inputs:
    @networkdataset = network dataset
    @impedance = [ "Meters" | "Minutes" ]
    @odstops = either a single feature class with two selected points or
               two separate feature classes with one point feature each.
    """
    # Check if input stops are points.
    for od in odstops:
        if gp.describe(od).shapetype != "Point":
            raise IOError("Input odstops must be a point feature class.")
        else:
            pass
    # Unpack start/end points.
    if len(odstops) == 1 and get_count_records(*odstops) == 2:
        stops = odstops[0]
    elif len(odstops) == 2:
        # Combine start/end points into single feature class.
        startpoint, endpoint = odstops
        #stops = get_featureclass_name(gp.workspace, "_stop_points")
        stops = os.path.join("in_memory", "_stop_points")
        if float(get_arcgis_version()) < 10:  # for ArcGIS 9.3 or earlier
            inputsMerge = "%s; %s" % (startpoint, endpoint)
            gp.merge_management(inputsMerge, stops)
        else:  # for ArcGIS 10.0 or later
            gp.merge_management([startpoint, endpoint], stops)
        if get_count_records(stops) != 2: raise Exception("Input stops must have exactly two points.")
    else:
        raise Exception("Input odstops must have two selected records or two separate single point feature classes.")
    
    # Find shortest path between two points.
    nalayer, naroute, natime = get_mapmatch_route(networkdataset, stops, impedance)
    
    # Convert shortest path to points.
    #vertices = get_featureclass_name(gp.workspace, "_gap_vertices")
    vertices = os.path.join("in_memory", "_gap_vertices")
    gp.featureverticestopoints_management(naroute, vertices, "ALL")
    # Delete intermediate data.
    delete_featureclass(nalayer, stops)
    return vertices
  
def run_test(inNetworkDataset, gpsTrajectory, spatialReference, _all=False):
    """
    Test method to check accuracy and performance of map-matching algorithm.
    """
    start = time.clock()
    #print "running tests for the module, please wait...\n"
    
    #print "test GPS trajectory: %s\n" % gpsTrajectory
    rs = RouteSolver(inNetworkDataset, gpsTrajectory, spatialReference)
    
    #print "\ntest 1: without barriers...\n"
    rs.get_mapmatch_route(withBarriers=False, return_line_only=True)  # shortest path
    
    if _all:
        #print "\ntest 2: with barriers..."
        rs.get_mapmatch_route(withBarriers=True, return_line_only=True)  # map-matched route
    
    end = time.clock()
    elapse = end - start
    #print "\nprocess time: %1.1f seconds" % elapse

if __name__ == '__main__':
    
    # Set required inputs: workspace, network dataset, projected coordinate system.
    gp.Workspace = r"P:\office_files\phd_dissertation\mapmatching\work\scratch\map-matching_test\test_output"  # working directory
    nd = r"P:\office_files\phd_dissertation\mapmatching\work\scripts\map-matching_from_darren\map-matching_shared_v2\data\network_dataset\CAN_GD.gdb\sample\sample_ND"  # network dataset
    prjfile = r"P:\office_files\phd_dissertation\mapmatching\work\scripts\map-matching_from_darren\map-matching_shared_v2\data\projected_coordinated_system\NAD_1983_UTM_Zone_20N.prj"  # projected coordinate system (*.prj)
    
    # Set input GPS trajectory for testing.
    gps = r"P:\office_files\phd_dissertation\mapmatching\work\scripts\map-matching_from_darren\map-matching_shared_v2\data\gps_trajectory\14640_20070403_17.shp"
    #gps = r"P:\office_files\phd_dissertation\mapmatching\work\scripts\map-matching_from_darren\map-matching_shared_v2\data\gps_trajectory\14640_20070403_17_colocated.shp"
    
    # Run the test case.
    run_test(nd, gps, prjfile, _all=True)
    
