"""
Tool Name: GERT Utility Functions
Source Name: gert_utils.py
Version:      ArcGIS 10.0 or 10.1, ArcInfo license
              (NOTE: can be used in 9.3 but needs retesting for the latest revision)
Creator: Ron Dalumpines (turugban@yahoo.com)
Requirements: Python 2.6 or later
Date Created: June 2, 2011
Last Revised: June 30, 2016
Description: A collection of utility functions that support most of GERT's modules.

Version History:
2013-08-06 (route_solver.py)

2016-06-29 (route_solver.py)
- updated RouteSolver class to expose max_gap (maxDistGap)

2016-06-30 (gert_utils.py)
- removed classes and some complicated functions found in GERT's modules

"""

# Imports.
import sys
import os
import math
import time
import fnmatch
import arcpy  # for methods in ArcGIS 10.0 or later
import arcgisscripting

# Create the geoprocessor object.
gp = arcgisscripting.create(9.3)  # allow backward compatibility down to ArcGIS 9.3

# Set the necessary product code.
gp.SetProduct("ArcInfo")

# Check out any necessary licenses.
gp.CheckOutExtension("Network")

# Set geoprocessor to overwrite output.
gp.OverwriteOutput = True

def all_files(root, patterns='*', single_level=False, yield_folders=False):
    """
    A generator function that iterate on the files rooted in a directory.
    """
    # Expand patterns from semicolon-separated string to list
    patterns = patterns.split(';')
    for path, subdirs, files in os.walk(root):
        if yield_folders:
            files.extend(subdirs)
        files.sort()
        for name in files:
            for pattern in patterns:
                if fnmatch.fnmatch(name, pattern):
                    yield os.path.join(path, name)
                    break
        if single_level:
            break

def list_files(infolder, file_patterns="*.xml"):
    """
    Return a list of files from input folder that meets specified patterns.
    """
    list_of_files = []
    for file in all_files(infolder, file_patterns):
        list_of_files.append(file)
    return list_of_files

def delete_files(infolder, donot_remove_list=[], file_patterns="*.xml"):
    """
    Delete files inside the input folder.
    """
    if infolder is None:
        #print "nothing to delete: there is no input folder specified"
        pass
    elif not isinstance(donot_remove_list, list):
        raise IOError("input must be a list of files that should not be removed")
    elif donot_remove_list:
        for file in all_files(infolder, file_patterns):
            if file not in donot_remove_list:
                try:
                    os.remove(file)
                except Exception, err:
                    #print "cannot delete %s: %s" % (os.path.basename(file), err.args)
                    pass
            else:
                pass
    else:  # delete all files
        for file in all_files(infolder, file_patterns):
            try:
                os.remove(file)
            except Exception, err:
                #print "cannot delete %s: %s" % (os.path.basename(file), err.args)
                pass

def get_folder(root, patterns='*', single_level=False):
    """
    Returns the folder name based on defined patterns.
    """
    # Expand patterns from semicolon-separated string to list
    patterns = patterns.split(';')
    for path, subdirs, files in os.walk(root):
        subdirs.sort()
        for name in subdirs:
            for pattern in patterns:
                if fnmatch.fnmatch(name, pattern):
                    folder = os.path.join(path, name)
                    if folder.split(os.sep)[-len(patterns):] == patterns:
                        return folder
                    break
        if single_level:
            break

def get_scratch_folder(prefix="mm_temp_"):
    scratch_folder = gp.CreateScratchName(prefix, "", "Folder", gp.GetSystemEnvironment("TEMP"))
    os.mkdir(scratch_folder)
    return scratch_folder

def get_count_records(infc):
    """
    Return the number of records in input feature class or shapefile.
    
    Inputs:
    @infc = input feature class or shapefile
    """
    try:  # ArcGIS 9.3 geoprocessor object
        result = gp.getcount_management(infc)
        count = int(result.getoutput(0))
    except:  # ArcGIS 9.2 geoprocessor object
        count = gp.getcount_management(infc)
    return count

def get_junction_layer(network_dataset):
    nd = gp.Describe(network_dataset)
    junc_sources = nd.JunctionSources
    junc_source = junc_sources.Reset()
    junc_source = junc_sources.Next()
    while junc_source:
        if nd.NetworkType != "SDC":
            if junc_source.SourceType == "SystemJunction":
                junc_fc = os.path.join(os.path.dirname(nd.CatalogPath), junc_source.Name)
                break
            else:
                pass
        else:
            if junc_source.Name:
                junc_fc = os.path.join(os.path.dirname(nd.CatalogPath), junc_source.Name)
                break
            else:
                pass 
        junc_source = junc_sources.Next()
    gp.MakeFeatureLayer_management(junc_fc, "junction_layer")
    return "junction_layer"

def select_fidlist(fidlist, infc):
    """
    Return a feature layer selection based on a list of feature IDs.
    
    Inputs:
    @fidlist = list of feature IDs
    @infc = input feature class or shapefile
    """
    if not isinstance(fidlist, list):
        raise IOError("fidlist must a list of feature IDs")
    infclayer = get_unique_layer(infc)
    oid = gp.describe(infc).oidfieldname
    start = True
    for fid in fidlist:
        expression = '"%s" = %s' % (oid, fid)
        if start:
            gp.selectlayerbyattribute_management(infclayer, "NEW_SELECTION", expression)
            start = False
        else:
            gp.selectlayerbyattribute_management(infclayer, "ADD_TO_SELECTION", expression)
    return infclayer

def get_directions(inNALayer, outFormat="XML"):
    """
    Retrieves and returns directions from network analysis layer into
    a specified output format.

    Output distance units in meters and time units in minutes.
    @inNALayer = analysis layer generated by get_mapmatch_routes
    @outFormat = output format [XML, TEXT] <- string
    """
    try:
        if not isinstance(outFormat, str):
            raise Exception("output format must be a string")
        if outFormat.lower() == "xml":
            fileName = "directions.xml"
        elif outFormat.lower() == "text":
            fileName = "directions.txt"
        else:
            raise Exception("output format must be either an XML or TEXT")
        outDirections = os.path.join(gp.ScratchWorkspace, fileName)
        gp.Directions_na(inNALayer, outFormat, outDirections, "Meters", "REPORT_TIME", "Minutes")
    except:
        raise
    else:
        return outDirections

def get_directions2(inNALayer, outFormat="XML", outBaseName=""):
    """
    Retrieves and returns directions from network analysis layer into
    a specified output format.

    Output distance units in meters and time units in minutes.
    @inNALayer = analysis layer generated by get_mapmatch_routes
    @outFormat = output format [XML, TEXT] <- string
    """
    try:
        if not isinstance(outFormat, str):
            raise Exception("output format must be a string")
        if outFormat.lower() == "xml":
            fileName = "%s_directions.xml" % outBaseName
        elif outFormat.lower() == "text":
            fileName = "%s_directions.txt" % outBaseName
        else:
            raise Exception("output format must be either an XML or TEXT")
        outDirections = os.path.join(gp.ScratchWorkspace, fileName)
        gp.Directions_na(inNALayer, outFormat, outDirections, "Meters", "REPORT_TIME", "Minutes")
    except:
        raise
    else:
        return outDirections

def get_featureclass_name(workspace, filename_without_extension):
    """
    Return a feature class name appropriate to a specified workspace.
    """
    if gp.Describe(workspace).DataType in ["Folder", "Workspace"]:
        if isinstance(filename_without_extension, str):
            pass
        else:
            raise Exception("File name must be in string format.")
    else:
        raise Exception("Workspace must be a full path to a folder or workspace.")
    try:
        if gp.Describe(workspace).WorkspaceType == "FileSystem":
            outputName = "%s.shp" % filename_without_extension
        else:
            outputName = filename_without_extension
        featureClassName = os.path.join(workspace, outputName)
    except:
        raise Exception("Failed to create feature class name.")
    else:
        return featureClassName

def delete_featureclass(*featureclass):
    """
    Deletes feature classes or tables.
    """
    for feature in featureclass:
        if not gp.exists(feature): continue
        desc = gp.describe(feature)
        if (desc.datatype == "ShapeFile") or (desc.datatype == "FeatureClass"):
            if gp.exists(desc.basename): gp.delete_management(desc.basename)
            gp.delete_management(desc.catalogpath)
        else:
            gp.delete_management(feature)
    gp.refreshactiveview()

def is_projected(infc):
    """
    Return True if the input feature class has projected coordinate system.
    
    Inputs:
    @infc = input feature class or shapefile
    """
    if gp.describe(infc).spatialreference.type != "Projected":
        return False
    else:
        return True

def has_coordsystem(infc):
    """
    Return True if the input feature class has coordinate system.
    """
    if gp.describe(infc).spatialreference.type == "Unknown":
        return False
    else:
        return True

def check_if_projected(*infc):
    """
    Return an error if input features are not projected.

    If input is a tuple or list, add an asterisk before the object to unpack;
    for example, check_if_projected(*inputlistfeatures).
    """
    for fc in infc:
        if not is_projected(fc):
            raise IOError("'%s' is not projected, please project the input feature then try again" % fc)
        else:
            pass

def check_if_canbeprojected(infc, spatial_reference):
    """
    Return an error if input is not projected or cannot be projected.
    """
    if not is_projected(infc):
        spatial_reference = get_spatial_reference(spatial_reference)
        if spatial_reference and spatial_reference.type == "Projected":
            pass
        else:
            raise Exception("Input feature class or spatial reference must be projected.")
    else:
        pass

def get_point_distance(startpoint, endpoint, radius="100 Kilometers"):
    """
    Return the straightline distance between two points in meters.
    
    The method assumes that input point feature classes are projected. Radius is
    initialized by default to avoid errors in various versions of ArcGIS.
    """
    # Check if inputs are projected.
    check_if_projected(startpoint, endpoint)
    # Get the distance between two points.
    gp.near_analysis(startpoint, endpoint, radius, "LOCATION", "ANGLE")
    rows = gp.searchcursor(startpoint)
    row = rows.next()
    pointdist = None
    while row:
        pointdist = round(row.getvalue("NEAR_DIST"))
        break
    del rows, row
    if pointdist is None: raise IOError("startpoint is an empty feature, failed to get distance between two points")
    return pointdist

def get_point_distance2(lat1, lon1, lat2, lon2):
    """
    Return the straightline distance between two points in meters.
    
    Input coordinates must be based on geographic coordinate system.
    """
    rLat1 = math.radians(lat1)
    rLon1 = math.radians(lon1)
    rLat2 = math.radians(lat2)
    rLon2 = math.radians(lon2)
    # Use the Haversine formula
    dLat = rLat2 - rLat1
    dLon = rLon2 - rLon1
    a = math.sin(dLat/2)**2 + math.cos(rLat1) * math.cos(rLat2) * math.sin(dLon/2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    distance = (6371 * c) * 1000  # meters
    return distance

def get_straightline_distance(x1, y1, x2, y2):
    """
    Return the straightline distance between point A(x1, y1) and point B(x2, y2).
    
    Input coordinates must be based on projected coordinate system.
    """
    return math.sqrt(math.pow(x2-x1, 2) + math.pow(y2-y1, 2))

def get_arcgis_version(InstallType="Desktop"):
    """
    Return the version of ArcGIS installed in string format.
    """
    try:
        gisVersion = gp.GetInstallInfo(InstallType)["Version"]  # GetInstallInfo method not available in ArcGIS 9.2 or earlier
    except:
        raise Exception("Methods work only on ArcGIS 9.3 or newer versions.")
    gisVersion = ".".join(gisVersion.split(".")[:2])  # reads the first 2 numbers in 9.3.1 version
    return gisVersion

def check_flayer(fcLayer):
    """
    Return True if input is a feature layer, False otherwise.
    """
    desc = gp.Describe(fcLayer)
    if desc.DataType != "FeatureLayer":
        return False
    else:
        return True

def point2line(inPts, outLine, IDField, sortField):
    """
    Return a line created from input point feature class or shapefile.
    
    This method validates sort and cursor fields provided by the user. If empty
    values are provided, the method assigns valid alternative values.
    
    This method coupled with createLinesFromPoints() method are adopted from
    methods originally created by David Wynne of ESRI. This method is particularly
    useful in ArcGIS 9.3 and 10.0 versions without this kind of functionality.
    
    Inputs:
    @inPts = input point feature class or shapefile
    @outLine = output polyline feature class or shapefile
    @IDField = field used to label each line (group of points)
    @sortField = field used to sort input points before converting to line
    """
    # Set the sort and cursor fields.
    if sortField == "#":
        sortField = ""

    if sortField == "":
        cursorSort = IDField
    else:
        cursorSort = IDField + ";" + sortField
    
    # Create lines from input points.
    createLinesFromPoints(inPts, outLine, IDField, cursorSort) 

def createLinesFromPoints(inPts, outLine, IDField, cursorSort):
    """
    Return a line created from input point feature class or shapefile.
    
    This method coupled with point2line() method are adopted from
    methods originally created by David Wynne of ESRI. This method is particularly
    useful in ArcGIS 9.3 and 10.0 versions without this kind of functionality.
    """
    try:
        # Assign empty values to cursor and row objects.
        iCur, sRow, sCur, feat = None, None, None, None

        shapeName = gp.Describe(inPts).ShapeFieldName

        # Create the output feature class.
        #
        outPath, outFC = os.path.split(outLine)
        gp.CreateFeatureClass(outPath, outFC, "Polyline", inPts, "", "", inPts)

        # Open an insert cursor for the new feature class
        #
        iCur = gp.InsertCursor(outLine)
        sCur = gp.SearchCursor(inPts, "", None, cursorSort, cursorSort)

        sRow = sCur.Next()

        # Create an array and point object needed to create features.
        #
        lineArray = gp.CreateObject("Array")
        pt = gp.CreateObject("Point")

        # Initialize a variable for keeping track of a feature's ID.
        #
        ID = -1
        while sRow:
            pt = sRow.GetValue(shapeName).GetPart(0)            
            currentValue = sRow.GetValue(IDField)

            if ID == -1:
                ID = currentValue

            if ID <> currentValue:
                if lineArray.count > 1:
                    feat = iCur.NewRow()
                    if ID: #in case the value is None/Null
                        feat.SetValue(IDField, ID)
                    feat.SetValue(shapeName, lineArray)
                    iCur.InsertRow(feat)
                else:
                    raise Exception("Not enough points to create a line for %s: %s" % (IDField, int(ID)))
                lineArray.RemoveAll()

            lineArray.Add(pt)
            ID = currentValue
            sRow = sCur.Next()

        # Add the last feature.
        #
        if lineArray.count > 1:
            feat = iCur.NewRow()
            if ID: #in case the value is None/Null
                feat.SetValue(IDField, currentValue)
            feat.SetValue(shapeName, lineArray)
            iCur.InsertRow(feat)
        else:
            raise Exception("Not enough points to create a line for %s: %s" % (IDField, int(ID)))
        lineArray.RemoveAll()

    except:
        raise
        
    finally:
        if iCur:
            del iCur
        if sRow:
            del sRow
        if sCur:
            del sCur
        if feat:
            del feat

def clear_selection(fcLayer):
    """
    Clears selection from a given layer.
    """
    if check_flayer(fcLayer):
        try:
            gp.SelectLayerByAttribute_management(fcLayer, "CLEAR_SELECTION", "")
        except Exception, err:
            gp.AddError("Error in clear_selection - %s" % err.message)
    else:  # input not a feature layer
        pass

def get_fieldinfo_hidden(inputFeature):
    """
    Return a field info where all fields in input feature are set to hidden.
    """
    if not gp.exists(inputFeature):  # check if input feature exists
        raise IOError("input feature does not exists")
    else:  # set all the fields in input feature as hidden
        fieldinfo = gp.Describe(inputFeature).fieldInfo
        index = 0
        while index < fieldinfo.count:
            fieldinfo.setvisible(index, "HIDDEN")
            index += 1
    return fieldinfo

def get_layer(inputFeature):
    """
    Returns a feature layer from input feature class.
    If input is already a layer then will return input as is.
    """
    # Make feature layer if not.
    if not check_flayer(inputFeature):
        inLayer = "%s_layer" % os.path.basename(inputFeature).split(".")[0]
        try:
            gp.MakeFeatureLayer_management(inputFeature, inLayer)
            #gp.AddMessage("Created new feature layer for: %s." % os.path.basename(inputFeature))
        except:
            raise
    else:  # no changes if input layer
        inLayer = inputFeature
    return inLayer

def get_unique_layer(inputFeature, fieldInfo="#"):
    """
    Return a unique feature layer created for input feature class.
    If feature layer already exists, it will create a new one.
    """
    # Check if input feature exists.
    if not gp.exists(inputFeature):
        raise IOError("input feature does not exists")
    else:  # create unique feature layer
        inLayer = "%s_layer" % gp.describe(inputFeature).basename
        uniqueLayer = inLayer  # assigns feature layer name
        uniqueNumber = 1
        while gp.exists(uniqueLayer):
            uniqueLayer = inLayer + str(uniqueNumber)
            uniqueNumber += 1
        gp.MakeFeatureLayer_management(inputFeature, uniqueLayer, "#", "#", fieldInfo)
    return uniqueLayer

def list_oids(fcLayer, sortField=None):
    """
    Return a list of sortField values.

    If sortField is None, then it will return a
    list of ObjectIDs.
    """
    try:
        if sortField is None: sortField = gp.Describe(fcLayer).OIDFieldName
        rows = gp.SearchCursor(fcLayer, "", "", "", sortField)
        row = rows.Next()
        oidList = []
        while row:
            oid = row.GetValue(sortField)
            oidList.append(oid)
            row = rows.Next()
        return oidList
    except:
        raise
    finally:
        del rows, row

def define_query(fieldname, fieldvalue):
    """
    Returns a structured query based on specified field input.
    """
    if isinstance(fieldvalue, str):
        sQuery = "\"%s\" = \'%s\'" % (fieldname, fieldvalue)
    elif isinstance(fieldvalue, int):
        sQuery = "\"%s\" = %i" % (fieldname, fieldvalue)
    elif isinstance(fieldvalue, float):
        sQuery = "\"%s\" = %f" % (fieldname, fieldvalue)
    return sQuery

def select_odpoints(inputFeature, sortField=None, startOID=0, endOID=-1):
    """
    Selects the first and last records in a layer.
    
    Inputs:
    @inputFeature = point feature class or shapefile
    @sortField = field used to sort points in inputFeature
    @startOID = index for first point in inputFeature
    @endOID = index for last point in inputFeature
    """
    try:
        # Check input if empty.
        numRecords = get_count_records(inputFeature)
        if numRecords < 2: raise Exception("Input must have atleast two records.") 
        # Get feature layer.
        inLayer = get_unique_layer(inputFeature)
        # Check sort field.
        if sortField is None or sortField.strip() == "":
            sortField = gp.Describe(inLayer).OIDFieldName
        # List ObjectIDs.
        oidList = list_oids(inLayer, sortField)
        # Create query.
        first = oidList[startOID]  # origin
        last = oidList[endOID]  # destination
        #print "startFID: %s, lastFID: %s" % (first, last)
        if isinstance(first, str):
            sQuery = "\"%s\" = \'%s\' OR \"%s\" = \'%s\'" % (sortField, first, sortField, last)
        elif isinstance(first, int):
            sQuery = "\"%s\" = %i OR \"%s\" = %i" % (sortField, first, sortField, last)
        elif isinstance(first, float):
            sQuery = "\"%s\" = %f OR \"%s\" = %f" % (sortField, first, sortField, last)
        # Select origin and destination points.
        gp.SelectLayerByAttribute_management(inLayer, "NEW_SELECTION", sQuery)
    except:
        raise
    return inLayer

def select_odpoints2(inputFeature, locType="origin", sortField=None):
    """
    Selects the first and last records in a layer.
    
    Inputs:
    @locType = location type ["origin", "destination", "both_od"]
    """
    try:
        # Check input if empty.
        numRecords = gp.GetCount_management(inputFeature)  # for ArcGIS 9.2 geoprocessor object
        if numRecords < 2: raise IOError("not enough points to process") 
        # Get feature layer
        inLayer = get_layer(inputFeature)
        # Check sort field.
        if sortField is None or sortField == "":
            sortField = gp.Describe(inLayer).OIDFieldName
        # List ObjectIDs.
        oidList = list_oids(inLayer, sortField)
        # Create query based on location type.
        if locType == "origin":
            rowFID = oidList[0]  # origin
        elif locType == "destination":
            rowFID = oidList[-1]  # destination
        elif locType == "both_od":  # origin and destination
            pass
        else:
            raise IOError("locType must be either 'origin', 'destination', or 'both_od'")
        # Remove ascending or descending flags in sortField.
        if len(sortField.split(" ")) == 2:
            sortField = sortField.split(" ")[0]
        # Select origin, destination, or both points.
        if locType != "both_od":
            sQuery = define_query(sortField, rowFID)
            gp.SelectLayerByAttribute_management(inLayer, "NEW_SELECTION", sQuery)
        else:
            sQuery = define_query(sortField, oidList[0])
            gp.SelectLayerByAttribute_management(inLayer, "NEW_SELECTION", sQuery)
            sQuery = define_query(sortField, oidList[-1])
            gp.SelectLayerByAttribute_management(inLayer, "ADD_TO_SELECTION", sQuery)
        #gp.AddMessage("Selected %s point." % locType)
        #print("Selected %s point." % locType)
    except Exception, err:
        gp.AddWarning("origin, destination, or both points not selected: %s" % err.message)
        raise

def select_odpoints3(inputFeature, sortField=None):
    """
    Selects the first and last records in a layer.
    """
    try:
        # Check input if empty.
        numRecords = gp.GetCount_management(inputFeature)  # for ArcGIS 9.2 geoprocessor object
        if numRecords < 2: raise Exception("not enough points to process") 
        # Get feature layer.
        inLayer = get_layer(inputFeature)
        # Check sort field.
        if sortField is None or sortField == "":
            sortField = gp.Describe(inLayer).OIDFieldName
        # List ObjectIDs.
        oidList = list_oids(inLayer, sortField)
        # Create query.
        first = oidList[0]  # origin
        last = oidList[-1]  # destination
        # Remove ascending or descending flags in sortField.
        if len(sortField.split(" ")) == 2:
            sortField = sortField.split(" ")[0]
        # Define structured query.
        if isinstance(first, str):
            sQuery = "\"%s\" = \'%s\' OR \"%s\" = \'%s\'" % (sortField, first, sortField, last)
        elif isinstance(first, int):
            sQuery = "\"%s\" = %i OR \"%s\" = %i" % (sortField, first, sortField, last)
        elif isinstance(first, float):
            sQuery = "\"%s\" = %f OR \"%s\" = %f" % (sortField, first, sortField, last)
        # Select origin and destination points.
        gp.SelectLayerByAttribute_management(inLayer, "NEW_SELECTION", sQuery)
        #gp.AddMessage("selected origin and destination points")
    except Exception, err:
        raise Exception("failed to select origin and destination points: %s" % err.args)

def get_point_barriers(gpsTrajectory, roadLayer, gpsLineBuffer, timeSortField):
    """
    Select road links that intersect the border of buffer region to create barriers.

    Inputs:
    @gpsTrajectory = sequence of GPS points
    @roadLayer = road network layer (used to identify links as barriers)
    @gpsLineBuffer = buffer around the GPS line trajectory
    @timeSortField = field used to sort GPS records (typically a time field)
    """
    try:
        # Select origin and destination points.
        try:
            fcLayer2 = select_odpoints(gpsTrajectory, timeSortField)
        except:
            raise
        # Select road links for conversion to point barriers.
        intersectTime = select_links_as_barriers(fcLayer2, roadLayer, gpsLineBuffer)
        # Convert selected road links to point barriers.
        if intersectTime:
            try:
                #outBarriers = get_featureclass_name(gp.workspace, "point_barriers")
                outBarriers = os.path.join("in_memory", "point_barriers")
                gp.FeatureToPoint_management(roadLayer, outBarriers, "INSIDE")
            except:
                raise
            else:
                return outBarriers, intersectTime
        else:
            raise Exception("Cannot generate point barriers.")
    except Exception:
        raise

def convert_points_to_line(inPoints, IDField, sortField=None):
    """
    Convert input point feature to line feature class.
    """
    try:
        # Assign fieldname to sort records.
        if sortField is None or sortField.strip() == "":
            sortField = gp.Describe(inPoints).OIDFieldName
        # Convert GPS points to line.
        #outLine = get_featureclass_name(gp.workspace, "_line")
        outLine = os.path.join("in_memory", "_line")
        try:
            arcpy.PointsToLine_management(inPoints, outLine, IDField, sortField)  # ArcGIS 10.1 (IMPORTANT: for this method,
                                                                                  # gp is recognized when run in ArcGIS Python Window, not in standalone mode (i.e. IDLE))
        except:
            point2line(inPoints, outLine, IDField, sortField)  # ArcGIS 10.0 or earlier versions
    except:
        raise
    else:
        delete_featureclass("_line")  # delete feature layer
        return outLine

def get_trajectory_length(inPoints, lineField=None, sortField=None):
    """
    Return the length of points if joined together as a line.
    
    This method assumes that input points are projected. Otherwise, it will
    raise an input/output error.
    """
    # Check if valid input.
    if not is_projected(inPoints):
        raise IOError("input feature class must be projected")
    elif gp.describe(inPoints).shapetype != "Point":
        raise IOError("input must be a point feature class")
    # Convert points to line.
    gpsLine = convert_points_to_line(inPoints, lineField, sortField)
    # Determine length.
    rows = gp.searchcursor(gpsLine)
    row = rows.next()
    length = None
    while row:
        length = row.shape.length
        row = rows.next()
    del rows, row
    if length is None: raise IOError("input feature class is empty")
    # Delete intermediate data.
    delete_featureclass(gpsLine)
    return length

def select_links_as_barriers(fcLayer, roadLayer, outBuffer, distance="100 Meters"):
    """
    Select road links for conversion to point barriers.
    
    Inputs:
    fcLayer = feature layer for GPS trajectory
    roadLayer = feature layer for road network
    outBuffer = output feature class for buffer operation
    distance = buffer distance
    """
    intersectStart = time.clock()
    try:
        # Select roads within a designated distance from origin and destination (OD) locations.
        gp.SelectLayerByLocation_management(roadLayer, "WITHIN_A_DISTANCE",
                                            fcLayer, distance, "NEW_SELECTION")
        # Select roads connected to previous selection.
        gp.SelectLayerByLocation_management(roadLayer, "BOUNDARY_TOUCHES",
                                            roadLayer, "", "ADD_TO_SELECTION")
        # Select roads that crossed the buffer line.
        gp.SelectLayerByLocation_management(roadLayer, "CROSSED_BY_THE_OUTLINE_OF",
                                            outBuffer, "", "ADD_TO_SELECTION")
        # Deselect roads within a designated distance from OD locations.
        gp.SelectLayerByLocation_management(roadLayer, "WITHIN_A_DISTANCE",
                                            fcLayer, distance, "REMOVE_FROM_SELECTION")
        # Deselect roads that are completely within the buffer zone.
        gp.SelectLayerByLocation_management(roadLayer, "COMPLETELY_WITHIN",
                                            outBuffer, "", "REMOVE_FROM_SELECTION")
    except:
        #raise Exception("selecting road links for conversion to point barriers not successful)
        return None
    else:
        intersectEnd = time.clock()
        intersectTime = intersectEnd - intersectStart
        return intersectTime

def get_line_buffer(inputLine, distBuff):
    """
    Return a tuple of buffer output and buffer time."
    """
    btimeStart = time.clock()
    try:  # create buffer around road centerlines
        if gp.Describe(inputLine).ShapeType != "Polyline":
            raise Exception('Input "%s" must be a line feature.' % os.path.basename(inputLine))
        outBuffer = get_featureclass_name(gp.workspace, "_line_buffer")
        #outBuffer = os.path.join("in_memory", "_line_buffer")
        gp.Buffer_analysis(inputLine, outBuffer, distBuff, "FULL", "ROUND", "ALL", "")
    except:
        #gp.AddWarning("Failed to generate the line buffer.")
        return None
    else:
        delete_featureclass("_line_buffer")  # delete feature layer
        btimeEnd = time.clock()
        bufferTime = btimeEnd - btimeStart
        return outBuffer, bufferTime

def get_line_barriers(inBuffer):
    """
    Return line barriers from the intersect of buffer outline and roads.
    """
    try:
        barrierStart = time.clock()
        # Make feature layer if not.
        inBufferLayer = get_unique_layer(inBuffer)
        #outBarriers = get_featureclass_name(gp.workspace, "_line_barriers")
        outBarriers = os.path.join("in_memory", "_line_barriers")
        gp.FeatureToLine_management(inBufferLayer, outBarriers)
    except:
        raise Exception("failed to generate line barriers")
    else:
        delete_featureclass(inBufferLayer)
        barrierEnd = time.clock()
        barrierTime = barrierEnd - barrierStart
        return outBarriers, barrierTime

def get_barriers(gpsPoints, IDfield, sortField=None, distBuff="50 meters", roadLayer=None):
    """
    Return the barriers used by the Network Analyst route solver.

    Inputs:
    @gpsPoints = sequence of GPS points or trajectory
    @IDfield = field used to identify GPS points of the same trajectory
    @sortField = field used to sort GPS records
    @distBuff = buffer distance used to select potential road links associated with GPS trajectory
    @roadLayer = road network layer used to select point barriers (ArcGIS 9.3 or earlier versions)
    """
    outLine = convert_points_to_line(gpsPoints, IDfield, sortField)
    outBuffer, bufferTime = get_line_buffer(outLine, distBuff)
    # Check ArcGIS version.
    if float(get_arcgis_version()) < 10:  # for ArcGIS 9.3 or earlier
        get_point_barriers(gpsPoints, roadLayer, outBuffer, sortField)
    else:  # for ArcGIS 10.0 or later
        outBarriers, barrierTime = get_line_barriers(outBuffer)
    # Delete intermediate data.
    delete_featureclass(outLine, outBuffer)
    return outBarriers

def load_barriers(routeLayer, inputBarriers):
    """
    Load input barriers into the network analysis (NA) or route layer.
    """
    if inputBarriers:
        # Set type of stop barriers appropriate for Network Analyst version.
        shapeType = gp.Describe(inputBarriers).ShapeType
        if float(get_arcgis_version()) < 10:  # for ArcGIS 9.3 or earlier
            if shapeType == "Point":
                typeBarriers = "Barriers"
            else:
                raise Exception("ArcGIS %s Network Analyst works only on point barriers." % get_arcgis_version())
        else:  # for ArcGIS 10.0 or later
            if shapeType == "Point":
                typeBarriers = "Point Barriers"
            elif shapeType == "Polyline":
                typeBarriers = "Line Barriers"
            elif shapeType == "Polygon":
                typeBarriers = "Polygon Barriers"
            else:
                raise Exception("Input barriers not a valid shape type.")
        
        # Load barriers.
        try:
            gp.AddLocations_na(routeLayer, typeBarriers, inputBarriers, "", "")
        except:
            raise Exception("Failed to load %s barriers." % typeBarriers)
    else:  # no barriers specified
        pass

def get_spatial_reference(spatialReference):
    """
    Return a spatial reference object.
    
    Inputs:
    @spatialReference = spatial reference object, projection file, or string representation
    """
    if spatialReference in [None, "", " "]:  # invalid input
        spatref = None
    elif isinstance(spatialReference, str) or isinstance(spatialReference, unicode):  # string input
        spatref = gp.createobject("SpatialReference")
        if os.path.splitext(spatialReference)[1] == ".prj":
            #print "spatialReference is a projection file"
            spatref.createfromfile(spatialReference)
        else:
            #print "spatialReference is a string input"
            spatref.loadfromstring(spatialReference)
    else:  # spatial reference object
        #print "spatialReference is a spatial reference object"
        spatref = spatialReference
    
    if (spatref is None) or (not spatref.type in ["Projected", "Geographic"]):
        raise IOError("spatialReference must be a spatial reference object or projection file (.prj)")
    else:
        return spatref

def extract_origin_destination(gpsTrajectory, sortField=None):
    """
    Return the origin and destination feature classes from GPS trajectory.
    """
    odLayer = select_odpoints(gpsTrajectory, sortField)
    origin = get_featureclass_name(gp.workspace, "_origin")
    destination = get_featureclass_name(gp.workspace, "_destination")
    fidlist = list_oids(odLayer, sortField)
    fidname = gp.describe(odLayer).oidfieldname
    start = True
    for fid in fidlist:
        expression = '"%s" = %s' % (fidname, fid)
        gp.selectlayerbyattribute_management(odLayer, "NEW_SELECTION", expression)
        if start:
            gp.copyfeatures_management(odLayer, origin)
            start = False
        else:
            gp.copyfeatures_management(odLayer, destination)
    delete_featureclass(odLayer)
    return origin, destination

def get_od_distance(points2compare, sortField=None, searchRadius="40030 Kilometers"):
    """
    Return the distance between first (origin) and last point (destination).
    """
    # Check if input is valid.
    if gp.describe(points2compare).shapetype != "Point":
        raise IOError("input must be a point feature class")
    # Create separate feature class for each point.
    origin, destination = extract_origin_destination(points2compare, sortField)
    # Get the distance between two points (in meters).
    try:
        gap_meters = get_point_distance(origin, destination, radius=searchRadius)
    except:
        raise
    finally:
        delete_featureclass(origin, destination)
    return gap_meters

def is_colocated(points2compare, gap_threshold=1, gap_meters=None, sortField=None):
    """
    Returs True if distance between the first and last points is within the gap threshold, False otherwise.

    Inputs:
    @points2compare = point feature class (if more than two points, first and last points are compared)
    @gap_threshold = distance in meters
    @sortField = fieldname used to sort records
    """
    # Get the distance between the origin and destination points.
    if gap_meters is None:
        gap_meters = get_od_distance(points2compare, sortField)
    # Determine if two points are colocated.
    if gap_meters > gap_threshold:  # exceeds gap threshold
        return False
    else:  # within gap threshold
        return True

def append_gap_vertices(fidlist, sourcefc, targetfc):
    """
    Inserts records from source to target feature class based on feature ID list.
    """
    # Select records with feature IDs in the list.
    subset = select_fidlist(fidlist, sourcefc)
    # Append selected records to target.
    if not gp.exists(targetfc):
        gp.copyfeatures_management(subset, targetfc)
    else:
        gp.append_management(subset, targetfc, "NO_TEST", "#", "#")
    delete_featureclass(subset)

def get_od_status(naStopsFeatureLayer="Stops"):
    """
    Return a dictionary of the status of origin and destination locations
    if they are located properly in Network Analyst's route layer.

    Inputs:
    @naStopsFeatureLayer = 'Stops' sublayer in route layer
    """
    rows = gp.searchcursor(naStopsFeatureLayer)
    row = rows.next()
    locationStatus = {}
    while row:
        name = row.getvalue('Name')
        status = row.getvalue('Status')
        locationStatus[name] = status
        row = rows.next()
    del rows, row
    return locationStatus

def get_code_relocate(locationStatus):
    """
    Return a code to identify what point to relocate: [ ORIGIN | DESTINATION | BOTH ].
    """
    if locationStatus["Location 1"] != 0:  # origin
        if locationStatus["Location 2"] != 0:  # destination
            codeRelocate = "BOTH"
        else:
            codeRelocate = "ORIGIN"
    elif locationStatus["Location 2"] != 0:
        codeRelocate = "DESTINATION"
    else:
        raise Exception("Location 1 (origin) and Location 2 (destination) status are okay.")
    return codeRelocate

def get_relocated_odlayer(gpsTrajectory, startValues=(0,-1), numStep=1, naStopsFeatureLayer="Stops", sortField=None):
    """
    Return a tuple of (feature layer, start feature ID, end feature ID) with new locations for origin and destination.
    """
    # Get a dictionary of OD locations and their status.
    locationStatus = get_od_status(naStopsFeatureLayer)
    # Identify what locations to relocate.
    codeRelocate = get_code_relocate(locationStatus)
    # Initialize feature IDs.
    startOID, endOID = startValues
    #print "start values: %s, %s" % (startOID, endOID)
    # Update feature IDs based on relocate code.
    if codeRelocate == "BOTH":
        #print "relocate BOTH"
        startOID += numStep; endOID += -numStep
    elif codeRelocate == "ORIGIN":
        #print "relocate ORIGIN"
        startOID += numStep
    elif codeRelocate == "DESTINATION":
        #print "relocate DESTINATION"
        endOID += -numStep
    #print "new values: %s, %s" % (startOID, endOID)
    newODLayer = select_odpoints(gpsTrajectory, sortField, startOID, endOID)
    return newODLayer, startOID, endOID

def split_colocated_points(infc, moveby=1, spatial_reference=""):
    """
    Relocates the first of the two colocated points.

    Inputs:
    @infc = input feature class
    @moveby = meters that the first point will be moved horizontally
    """
    # Check if input is projected or can be projected.
    check_if_canbeprojected(infc, spatial_reference)
    # Check if input has exactly two points.
    if gp.describe(infc).shapetype != "Point":
        raise Exception("Input must be a point feature class.")
    else:
        numRecords = get_count_records(infc)
        if numRecords != 2:
            od2split = select_odpoints(infc)
        else:
            od2split = infc
    # Relocate the first point by changing its X coordinate.
    shapename = gp.describe(od2split).shapefieldname
    feat = gp.createobject("Point")
    rows = gp.updatecursor(od2split, "", spatial_reference)
    row = rows.next()
    firstrecord = True
    while row:
        pt = row.getvalue(shapename).getpart(0)
        feat.X = pt.X + moveby  # new X coordinate
        feat.Y = pt.Y
        if firstrecord:
            row.setvalue(shapename, feat)
            rows.updaterow(row)
            firstrecord = False
        row = rows.next()
    del rows, row
    if numRecords != 2: delete_featureclass(od2split)
    gp.refreshactiveview()

def get_new_featureclass(filename_without_extension, geometry_type="POINT", spatial_reference="", is_temporary=False):
    """
    Return a newly created feature class.
    """
    if is_temporary:
        infc = os.path.join("in_memory", filename_without_extension)
    else:
        infc = get_featureclass_name(gp.workspace, filename_without_extension)
    delete_featureclass(infc)  # overwrite existing file
    out_path, out_name = os.path.split(infc)
    template, has_m, has_z = None, "DISABLED", "DISABLED"
    gp.CreateFeatureclass_management(out_path, out_name, geometry_type, template, has_m, has_z, spatial_reference)
    return infc

def get_points_from_coordinates(coordlist, spatial_reference):
    """
    Return a point feature class created from a list of coordinates.
    
    Inputs:
    @coordlist = list of coordinates: [[x1, y1], [x2, y2], ...]
    @spatial_reference = spatial reference
    """
    # Must have a spatial reference.
    if not spatial_reference:
        raise IOError("Spatial reference object type must be either Geographic or Projected.")
    infc = get_new_featureclass("_xy_points", "POINT", spatial_reference, is_temporary=True)
    shapename = gp.describe(infc).shapefieldname
    pt_array = gp.createobject("Array")
    pt  = gp.createobject("Point")
    rows = gp.insertcursor(infc, spatial_reference)
    for coord in coordlist:
        pt.X, pt.Y = coord[0], coord[1]
        #print "x: %s, y: %s" % (pt.X, pt.Y)
        feat = rows.newrow()
        feat.setvalue(shapename, pt)
        rows.insertrow(feat)
    del rows, feat, pt_array, pt
    return infc

def get_nd_attributes(network_dataset):
    """
    Return a list of network dataset attributes.
    """
    attr_list = []
    nd_attributes = gp.describe(network_dataset).attributes
    attr = nd_attributes.next()
    while attr:
        attr_list.append(attr.name.lower())
        attr = nd_attributes.next()
    return attr_list

def is_valid_impedance(impedance, nd_attributes):
    """
    Return True if impedance is an attribute of network dataset, False otherwise.

    Inputs:
    @impedance = impedance attribute [ "Meters" | "Minutes" ]
    @nd_attributes = list of network dataset attributes
    """
    if impedance.lower() in nd_attributes:
        return True
    else:
        return False

