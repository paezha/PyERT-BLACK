"""
Tool Name:    Route Choice Analysis Utility Functions
Source Name:  rca_utils.py
Version:      ArcGIS 9.3 or later (ArcMap or Advanced License)
Author:       Ron Dalumpines (turugban@yahoo.com)
Requirements: Python 2.6 or later, Numpy 1.6.1 or later
Date Created: May 9, 2012
Last Revised: June 29, 2016
Description:  A collection of utility functions used to generate a suite of
              variables for route choice analysis (RCA).

Version History:
2012-05-09 (rca_improved.py)

2016-06-29 (rca_utils.py)
"""

# Import modules.
import sys
import os
import arcgisscripting
import time
import re
import fnmatch
import traceback

from xml.parsers import expat
from numpy import math, mean, std, percentile

import gert_utils as gert

# Create the geoprocessor object.
gp = arcgisscripting.create()

# Set the necessary product code.
gp.SetProduct("ArcInfo")

# Check out any necessary licenses.
gp.CheckOutExtension("Network")

# Overwrite the output.
gp.OverwriteOutput = True

def SplitMultiInputs(multiInputs):
    """
    Split the semi-colon (;) delimited input string (tables or feature classes) into a list.
    """
    try:
        # Remove the single quotes and parenthesis around each input featureclass
        # Changed at June 2007, instead of replace "(" and ")" with "",
        # just strip them if they're first or last character in multiInputs
        multiInputs = multiInputs.replace("'","")
        if multiInputs.startswith("("):
            multiInputs = multiInputs[1:]
        if multiInputs.endswith(")"):
            multiInputs = multiInputs[:-1]
        # Split input tables by semicolon ";".
        return multiInputs.split(";")
    except:
        raise Exception, "Problem encountered parse input list"

# Create a parser object for NA Directions in XML format
class ParserDirectionsXML:
    """
    Returns an object to parse Network Analyst directions in XML format.

    The object has been developed for ArcGIS 10.0 with ArcInfo license.
    """
    def __init__(self):
        self._parser = expat.ParserCreate()
        if float(gert.get_arcgis_version()) < 10:  # for ArcGIS 9.3.1 or earlier
            self._parser.StartElementHandler = self.start_arc93
        else:  # for ArcGIS 10.0 or later
            self._parser.StartElementHandler = self.start_arc10
        self.list = []
        self.direction_id = None
        self.instruction = None

    def feed(self, xml_file):
        try:
            self._parser.ParseFile(open(xml_file, "rb"))
        except MemoryError:
            # Destroy parser object and create new
            del self._parser
            self.__class__.__init__(self)
            self._parser.ParseFile(open(xml_file, "rb"))

    def parse_street_name(self):
        try:
            if not isinstance(self.direction_id, int) or self.direction_id < 2:
                raise Exception("self.direction_id parameter must be an integer > 1")
            if self.direction_id == 2:
                i = re.search(r"\son\s", self.instruction)  # "on"
                j = re.search(r"\stoward\s", self.instruction)  # "toward"
                streetname = self.instruction[i.end():j.start()]
            elif self.direction_id > 2:
                i = re.search(r"\son\s", self.instruction)  # "on"
                j = len(self.instruction)  # last index
                streetname = self.instruction[i.end():j]
            # Remove repetition of road type
            s = streetname.split(" ")
            if s[-1] == s[-2]:
                return " ".join(s[:-1])
            else:
                return " ".join(s)
        except (AttributeError, IndexError):
            return None
        except:
            raise

    def start_arc93(self, tag, attrs):
        """
        Parsing rules for directions generated in ArcGIS 9.3.1 or earlier.
        """
        if tag == "DIRECTION" and attrs["id"] != "1":
            if self.list:
                # Update for missing street name
                p = self.list
                try:
                    if p[-1].has_key("street_name"):
                        pass
                    else:
                        p[-1].update({"street_name":p[-2]["street_name"]})
                except IndexError:
                    p[-1].update({"street_name":"UNKNOWN"})
            else:
                pass
            if attrs["id"] != "summary":
                self.list.append(attrs)
                self.direction_id = int(attrs["id"])
            elif not self.list:  # capture very short segments
                self.list.append(attrs)
                self.list[-1].update({"street_name":"UNKNOWN"})
                self.list[-1].update({"maneuvertype":"straight"})
        elif attrs.has_key("style") and attrs["style"] == "normal":
            # Extract street name
            self.instruction = attrs["text"]
            street_name = self.__class__.parse_street_name(self)
            if street_name: self.list[-1].update({"street_name":street_name})
            # Add maneuvertype
            if not self.list[-1].has_key("maneuvertype"):
                self.list[-1].update({"maneuvertype":self.__class__.get_turns_arc93(self)})
        elif attrs.has_key("style") and attrs["style"] == "arrive":
            del self.list[-1]  # remove entry for arrival at destination

    def start_arc10(self, tag, attrs):
        """
        Parsing rules for directions generated in ArcGIS 10.0 or later.
        """
        if tag == "DIRECTION" and attrs["maneuvertype"] not in ["depart", "unknown"]:
            if self.list:
                # Update for missing street name
                p = self.list
                try:
                    if p[-1].has_key("street_name"):
                        pass
                    else:
                        p[-1].update({"street_name":p[-2]["street_name"]})
                except IndexError:
                    p[-1].update({"street_name":"UNKNOWN"})
            else:
                pass
            if attrs["maneuvertype"] != "stop":
                self.list.append(attrs)
            elif not self.list:  # capture very short segments
                self.list.append(attrs)
                self.list[-1].update({"street_name":"UNKNOWN"})
        elif attrs.has_key("style") and attrs["style"] == "street_name":
            # Remove repetition of road type
            s = attrs["text"].split(" ")
            if len(s) > 1 and s[-1] == s[-2]:
                street_name = " ".join(s[:-1])
            elif len(s) > 4 and s[-4:-3] == s[-2:-1]:
                street_name = " ".join(s[:-2])
            else:
                street_name = " ".join(s)
            self.list[-1].update({"street_name":street_name})

    def get_total_distance(self):
        if self.list:
            return sum([float(x["distance"]) for x in self.list])
        else:
            return None

    def get_total_time(self):
        if self.list:
            return sum([float(x["time"]) for x in self.list])
        else:
            return None

    def get_unique_dict(self):
        xlist = []; xlist.extend(self.list)
        kset, udict = set(), {}
        while xlist:
            m = xlist.pop()
            st = m["street_name"]
            distance, time = float(m["distance"]), float(m["time"])
            if st not in kset:
                kset.add(st)
                udict[st] = {"distance":distance, "time":time}
            else:
                udict[st]["distance"] += distance
                udict[st]["time"] += time
        return udict

    def count_segments(self):
        if self.list:
            return len(self.list)
        else:
            return None

    def count_unique_segments(self):
        d = self.__class__.get_unique_dict(self)
        if d:
            return len(d)
        else:
            return None

    def get_turns_arc93(self):
        for turntype in ["turn left", "turn right", "sharp left", "sharp right"]:
            maneuvertype = re.findall(turntype, self.instruction, flags=re.IGNORECASE)
            if maneuvertype:
                maneuvertype = "_".join(turntype.split(" "))
                break
            else:
                pass
        else:
            maneuvertype = "straight"
        return maneuvertype

    def get_longleg_attribute(self, attr):
        """
        Get longest leg or segment attribute specified as a string.

        @attr = name | distance | time <- string
        """
        if not isinstance(attr, str):
            raise Exception("attr must be a string")
        if attr not in ["name", "distance", "time"]:
            raise Exception("attr must be one of the following: name, distance, time")
        d = self.__class__.get_unique_dict(self)
        if d and attr == "distance":
            return max([d[k]["distance"] for k in d.keys()])
        elif d and attr == "time":
            return max([d[k]["time"] for k in d.keys()])
        elif d and attr == "name":
            maxd = max([d[k]["distance"] for k in d.keys()])
            name = [k for k in d.keys() if d[k]["distance"] == maxd]
            return name[0]  # street name of longest segment (based on distance)
        else:
            return None
    
    def count_turns(self, turntype):
        """
        Count the number of turns for a specified turn type.
        
        @turntype = turn_right | turn_left | sharp_right |
                    sharp_left | total_turns <- string
        """
        if not isinstance(turntype, str):
            raise Exception("turntype must be a string")
        items = ["turn_right", "turn_left", "sharp_right", "sharp_left", "total_turns"]
        if turntype not in items:
            raise Exception("turntype must be one of the following: \n\tturn_right, turn_left, "\
                            "sharp_right, sharp_left, total_turns")
        if self.list and turntype != "total_turns":
            return len([x["maneuvertype"] for x in self.list if x["maneuvertype"] == turntype])
        elif self.list and turntype == "total_turns":
            total = 0
            for tturn in ["turn_right", "turn_left", "sharp_right", "sharp_left"]:
                total += len([x["maneuvertype"] for x in self.list if x["maneuvertype"] == tturn])
            return total
        else:
            return None

class ParserDirectionsXML2(ParserDirectionsXML):
    def __init__(self, inNALayer):
        ParserDirectionsXML.__init__(self)
        self.directionXML = gert.get_directions(inNALayer, outFormat='XML')
        self.feed(self.directionXML)
        self.countLeftTurn = self.count_turns("turn_left")
        self.countRightTurn = self.count_turns("turn_right")
        self.countSharpLeft = self.count_turns("sharp_left")
        self.countSharpRight = self.count_turns("sharp_right")
        self.countAllTurns = self.count_turns("total_turns")

def get_turns(outDirections):
    """
    Returns the number of turns as a tuple.
    """
    try:
        inFile = open(outDirections)
        inString = inFile.read()
        leftTurns = len(re.findall("turn left", inString, flags=re.IGNORECASE))
        rightTurns = len(re.findall("turn right", inString, flags=re.IGNORECASE))
        sharpLeft = len(re.findall("sharp left", inString, flags=re.IGNORECASE))
        sharpRight = len(re.findall("sharp right", inString, flags=re.IGNORECASE))
        return leftTurns, rightTurns, sharpLeft, sharpRight
    except Exception, err:
        gp.AddError("error in get_turns: %s" % err.message)
    finally:
        inFile.close()

def get_coordinates(fcLayer, spatialRefStr=None):
    """
    Returns lat, lon coordinates for origin and destination points.

    @origin = first record
    @destination = last record
    """
    # Select origin and destination points
    gert.select_odpoints3(fcLayer)
    # Check spatial reference if geographic
    if spatialRefStr is None:
        desc = gp.Describe(fcLayer)
        spatialRef = desc.SpatialReference
    else:
        spatialRef = gp.CreateObject("spatialreference")
        spatialRef.LoadFromString(spatialRefStr)
    if spatialRef.Type == "Geographic":
        try:
            # Get coordinates
            desc = gp.Describe(fcLayer)
            rows = gp.SearchCursor(fcLayer, "", spatialRef, "", desc.OIDFieldName)
            row = rows.Next()
            origin_xy = True
            while row:
                pnt = row.shape.getpart()
                lat = pnt.y
                lon = pnt.x
                if origin_xy:
                    origLat = lat
                    origLon = lon
                    origin_xy = False
                else:
                    destLat = lat
                    destLon = lon
                row = rows.Next()
            return origLat, origLon, destLat, destLon
        except:
            raise
        finally:
            del rows, row, origin_xy
            # Clear selection
            gert.clear_selection(fcLayer)   
    else:
        raise Exception("Spatial reference must be geographic. Please specify new spatial reference file.")

def parse_direction(outDirections):
    """
    Returns a tuple of variables parsed from directions file.
    
    Input: Directions file in text format created by Network Analyst
    Output: (D, numSeg, uniqSeg)
    @D = Dictionary of driving time and distance for each route segments,
    with the following parameters:
    @keys = street name
    @values = {"distance":distance, "time":time}

    @numSeg = total number of route segments
    @uniqSeg = total number of unique route segments, i.e. several
    segments with the same street name counts as one

    NOTE: Tool works only for ArcGIS 10.0 or later. Previous ArcGIS
    versions have different schema for directions file. A more efficient
    parser can be developed for directions in xml format.
    """
    try:
        inFile = open(outDirections)
        inString = inFile.read()
        L = re.split(r"\n+", inString)
        D = {}
        uniqSeg = 0
        numSeg = 0
        for line in L:
            try:
                # Get numbering of driving directions
                step = int(re.search(r"(?P<num>\d+):", line).groupdict()["num"])
            except:
                pass
            else:
                # Extract street name
                if step == 2:
                    i = re.search(r"\son\s", line)  # "on"
                    j = re.search(r"\s\w+\stoward\s", line)  # "toward"
                    streetname = line[i.end():j.start()]
                elif step > 2:
                    i = re.search(r"\son\s", line)  # "on"
                    k = re.split(r"\s", line)
                    j = re.search(r"\s" + k[-1], line)  # last word in line
                    streetname = line[i.end():j.start()]
            param = re.split(r"\s", line)
            # Extract distance and time values
            try:
                distance = float(param[1])
                time = float(param[-2])
            except:
                pass
            else:
                # Count number of route segments
                numSeg += 1
                # Sum distance, time for the same street name
                if streetname in D.keys():
                    D[streetname]["distance"] += distance
                    D[streetname]["time"] += time
                else:  # add new entry
                    D[streetname] = {"distance":distance, "time":time}
                    # Count unique segments based on street name
                    uniqSeg += 1
        return D, numSeg, uniqSeg
    except Exception, err:
        gp.AddError("error in parse_direction: %s" % err.message)
    finally:
        inFile.close()

def get_longleg(outDirections):
    """
    Returns a tuple of longest route segment (streetname, distance).

    Distance unit: Meters
    """
    # Get dictionary of streetname, distance, time
    D, numSeg, uniqSeg = parse_direction(outDirections)
    # Get distance of longest route segment
    longLegDist = max([D[k]["distance"] for k in D.keys()])
    # Get streetname of longest route segment
    for k in D.keys():
        if D[k]["distance"] == longLegDist:
            longLegName = k
    return longLegName, longLegDist

def get_total_timedist(outDirections):
    """
    Returns a tuple of total time and distance.

    Time unit: Minutes
    Distance unit: Meters
    Output: (totTime, totDistance)
    """
    inFile = open(outDirections)
    inString = inFile.read()
    L = re.split(r"\n+", inString)
    if L[-1] == "":
        t, d = -4, -3
    else:
        t, d = -3, -2
    timeL = re.split(r"\s", L[t])
    distL = re.split(r"\s", L[d])
    totTime = float(timeL[-2])
    totDist = float(distL[-2])
    inFile.close()
    return totTime, totDist

def get_projectedlyr(inputFeature, spatref):
    """
    Checks if input is a feature layer and  projected. Returns a
    layer and spatial reference object.
    """
    # Make feature layer if not
    inLayer = gert.get_layer(inputFeature)
    # Spatial reference must be projected
    if spatref:
        spatialRef = spatref
    else:
        desc = gp.Describe(inLayer)
        spatialRef = desc.SpatialReference
    if spatialRef.Type == "Geographic":
        raise Exception("Input must be projected. Please specify a new spatial reference and try again.")
    else:
        pass # projected coordinate system
    return inLayer, spatialRef

def update_timedistfields(outSegments,
                          fnDistance="RDLEN_M",
                          fnTime="FT_MINUTES",
                          spatref=""):
    """
    Updates the time and distance field values after clip operation.
    """
    try:
        # Check if projected layer
        inLayer, spatialRef = get_projectedlyr(outSegments, spatref)
        # Update fied values
        rows = gp.UpdateCursor(inLayer, "", spatialRef)
        row = rows.Next()
        while row:
            d = row.GetValue(fnDistance)
            t = row.GetValue(fnTime)
            nd = row.shape.length
            if int(round(d)) != int(round(nd)):
                nt = (nd/d) * t
                row.SetValue(fnTime, nt)
                row.SetValue(fnDistance, nd)
                rows.UpdateRow(row)
            else:
                pass  # no need to update
            row = rows.Next()
    except:
        raise
    finally:
        # Clean up
        del rows, row

def get_empty_attributes():
    """
    Returns a dictionary of attribute values that are empty or null.
    """
    return {0:{
        "distance":sys.maxint,
        "time":sys.maxint,
        "speed":sys.maxint,
        "rdname":"UNAVAILABLE",
        "rdclass":sys.maxint,
        "rddesc":"UNAVAILABLE"}}

def get_attributes(outSegments,
                   fnDistance="RDLEN_M",  # length in meters <- float
                   fnTime="FT_MINUTES",  # time in minutes <- float
                   fnSpeed="SPD_KM",  # travel time in km/h <- int or float
                   fnRdName="FULL_NAME",  # street name (e.g. Main St) <- str
                   fnRdClass="CARTO",  # road classification (numeric codes) <- int
                   fnRdDesc="TYPE",  # road class description or type <- str
                   spatref=""):  # spatial reference <- object
    """
    Returns a dictionary of attributes of the route segments.

    Input: Feature class
    Output: Dictionary D[k]=v with the following parameters:
    @k = OIDFieldName (integer)
    @v = {"distance":fnDistance, "time":fnTime, "speed":fnSpeed,
    "rdname":fnRdName, "rdclass":fnRdClass, "rddesc":fnRdDesc}
    """
    try:
        # Check if projected layer
        inLayer, spatialRef = get_projectedlyr(outSegments, spatref)
    except Exception, err:
        gp.AddError("error in get_projectedlyr: %s" % err.message)
    try:
        # Update distance and time field values
        update_timedistfields(inLayer, fnDistance, fnTime, spatialRef)
    except Exception, err:
        gp.AddError("error in update_timedistfields: %s" % err.message)
    try:
        # Extract route attributes
        desc = gp.Describe(inLayer)
        rows = gp.SearchCursor(inLayer)
        row = rows.Next()
        D = {}
        while row:
            k = row.GetValue(desc.OIDFieldName)
            D[k] = {
                "distance":row.GetValue(fnDistance),
                "time":row.GetValue(fnTime),
                "speed":row.GetValue(fnSpeed),
                "rdname":row.GetValue(fnRdName),
                "rdclass":row.GetValue(fnRdClass),
                "rddesc":row.GetValue(fnRdDesc)
                }
            row = rows.Next()
        if not D: D = get_empty_attributes()  # empty dictionary
        return D
    except:
        raise
    finally:
        # Clean up
        del rows, row, inLayer

def pmode(aList):
    """
    Returns the most popular (most frequent) item in the list.

    Only one item is returned in case of tie.
    """
    D = {}
    for i in aList:
        D[i] = aList.count(i)
    mk = max([D[k] for k in D.keys()])
    return [k for k in D.keys() if D[k] == mk][0]

def group_attrib_by_rdname(D):
    """
    Group route segment attributes by road name.

    Input parameter:
    @D = dictionary of route attributes returned by get_attributes(...)

    Returns a new dictionary B[k] = v where,
    @k = numeric code (1...n), where n = total number of unique road names
    @v = {x1:[x1v1, x1v2,...x1vn], ..., xn:[xnv1, xnv2, ...xnvn]}
    Note: It is assumed that the road network have unique names.
    """
    A, B = {}, {}
    A.update(D)
    rdnames = set([A[k]["rdname"] for k in A.keys()])
    for m, n in enumerate(rdnames):
        B[m+1] = {"rdname":n, "distance":[], "rdclass":[], "time":[], "rddesc":[], "speed":[]}
        for k in A.keys():
            if A[k]["rdname"] == n:
                p = A.pop(k)
                B[m+1]["distance"].append(p["distance"])
                B[m+1]["rdclass"].append(p["rdclass"])
                B[m+1]["time"].append(p["time"])
                B[m+1]["rddesc"].append(p["rddesc"])
                B[m+1]["speed"].append(p["speed"])
    return B

def summarize_attrib_by_rdname(D):
    """
    Summarize route segment attributes by road name.

    Returns a new dictionary, with attribute values summarized as follows:
    1) Sum values for time and distance.
    2) Average values for speed.
    3) Most popular/frequent item for string or numeric codes.
    """
    A = group_attrib_by_rdname(D)
    for k, v in A.items():
        A[k] = {
            "time":sum(v["time"]),
            "distance":sum(v["distance"]),
            "speed":mean(v["speed"]),
            "rdclass":pmode(v["rdclass"]),
            "rddesc":pmode(v["rddesc"]),
            "rdname":v["rdname"]
            }
    return A

def carto_share(numCarto, legCarto, attrLegVal, attrTotVal):
    """
    Returns a portion of the attribute value for a given carto class.

    Parameters:
    @numCarto = cartographic road classification (1 to 5)
    @legCarto = road class of the longest leg
    @attrLegVal = attribute value of the longest leg (e.g. distance)
    @attrTotVal = total value of the attribute under consideration
    """
    if numCarto == legCarto:
        share = attrLegVal/attrTotVal
    else:
        share = 0
    return share

def get_intersections(vtxLayer, roadLayer):
    """
    Returns a dictionary of intersections with valence values.
    
    Inputs: route vertices/nodes layer, road network layer
    Output: dictionary D[k] = v where
    @k = id number
    @v = {"objectid":fid, "valence":valence}
    Note: Valence refers to the number of edge elements that are
    adjacent to a single vertex/node/junction. For more info,
    see the documentation on INetworkQuery Interface (ArcObjects).
    """
    # Remove duplicate points.
    pointFeature = remove_duplicate_points(vtxLayer)
    # Make feature layer if not.
    nodeLayer = gert.get_layer(pointFeature)
    edgeLayer = gert.get_layer(roadLayer)
    #gp.AddMessage("Extracting intersections for the specified route. Please wait...")
    try:
        desc = gp.Describe(nodeLayer)
        fieldName = desc.OIDFieldName
        try:
            # Get list of input records.
            fidList = []
            rows = gp.SearchCursor(nodeLayer)
            row = rows.Next()
            while row:
                fid = row.GetValue(fieldName)
                fidList.append(fid)
                row = rows.Next()
        except:
            raise
        finally:
            del rows, row
        # Search for intersections and get valence values.
        xingDict = {}
        counter = 1
        for fid in fidList:
            sQuery = "\"%s\" = %i" % (fieldName, fid)
            gp.SelectLayerByAttribute_management(nodeLayer, "NEW_SELECTION", sQuery)
            gp.SelectLayerByLocation_management(edgeLayer,"INTERSECT", nodeLayer)
            valence = gp.GetCount_management(edgeLayer)
            if valence > 2:
                xingDict[counter] = {"objectid":fid, "valence":valence}
                counter += 1
        #gp.AddMessage("\textraction of intersections and valence values completed")
        return xingDict
    except Exception, err:
        gp.AddError("error in get_intersections: %s" % err.message)
    finally:
        gert.clear_selection(nodeLayer)
        gert.clear_selection(edgeLayer)
        gp.Delete_management(pointFeature)

def count_stops(stopLayer, routeLayer, searchDist=None):
    """
    Returns the number of stops that intersect with a given route."

    Search distance can be adjusted to account for locational
    errors between input layers.
    """
    # Make feature layer if not.
    inputLayer = gert.get_layer(stopLayer)
    selectLayer = gert.get_layer(routeLayer)
    # Search for and count stops.
    try:
        gp.SelectLayerByLocation_management(inputLayer, "INTERSECT", selectLayer, searchDist)
        numStops = gp.GetCount_management(inputLayer)
        return numStops
    except Exception, err:
        gp.AddError("failed to count intersections: %s" % err.args)
    finally:
        gert.clear_selection(inputLayer)
        gert.clear_selection(selectLayer)

def remove_duplicate_points(pointLayer):
    """
    Removes duplicate points and returns a feature class.

    Duplicate means the same x, y coordinates.
    """
    # Make feature layer if not.
    inputLayer = gert.get_layer(pointLayer)
    # Check if point feature.
    desc = gp.Describe(inputLayer)
    if desc.ShapeType != "Point":
        raise Exception("Input must be point feature.")
    else:  # search for and remove duplicates
        try:
            gert.clear_selection(inputLayer)
            vList, vDict = [], {}
            rows = gp.UpdateCursor(inputLayer, "", "", "", desc.OIDFieldName)
            row = rows.Next()
            while row:
                fid = row.getvalue(desc.OIDFieldName)
                feat = row.shape
                pnt = feat.getpart()
                x, y = pnt.x, pnt.y
                #gp.AddMessage("x: %.5f, y: %.5f" % (x, y))
                if vList:
                    p = vList[-1]
                    a, b = vDict[p]
                    if (a, b) == (x, y):
                        try:
                            sQuery = "\"%s\" = %i" % (desc.OIDFieldName, fid)
                            gp.SelectLayerByAttribute_management(inputLayer, "ADD_TO_SELECTION", sQuery)
                            #gp.AddWarning("duplicate objectid %i added to selection" % fid)
                        except Exception, err:
                            gp.AddError("error in selecting duplicate row: %s" % err.message)
                    else:
                        vDict[fid] = x, y
                        vList.append(fid)
                        #gp.AddWarning("duplicate objectid %i added to selection" % fid)
                else:
                    vDict[fid] = x, y
                    vList.append(fid)
                row = rows.Next()
        except Exception, err:
            gp.AddError("error in remove_duplicate_points: %s" % err.message)
        finally:
            del rows, row, vDict, vList
        try:
            gp.SelectLayerByAttribute_management(inputLayer, "SWITCH_SELECTION")
            #gp.AddMessage("switched selection to non-duplicate points")
            # Copy non-duplicate points selection to a new feature class
            #noDuplicates = gert.get_featureclass_name(os.path.split(gp.ScratchWorkspace)[0], "noDuplicates")
            noDuplicates = os.path.join("in_memory", "noDuplicates")
            gp.CopyFeatures_management(inputLayer, noDuplicates)
            #gp.AddMessage("copied %s to a new feature class without duplicates: %s" %
            #              (os.path.basename(inputLayer), os.path.basename(noDuplicates)))
            return noDuplicates
        except:
            raise

def get_distance_multiline_feature(inputFeature, spatref):
    """
    Returns the total length in meters of a multi-line feature.
    """
    inLayer, spatialRef = get_projectedlyr(inputFeature, spatref)
    try:
        rows = gp.SearchCursor(inLayer, "", spatialRef)
        row = rows.Next()
        totLength = 0
        while row:
            feat = row.shape
            totLength += feat.Length
            row = rows.Next()
    except:
        raise
    finally:
        del rows, row
    try:
        if spatialRef.LinearUnitName.lower() != "meter":
            raise Exception("distance unit not in meters, please specify the correct spatial reference")
    except Exception, err:
        gp.AddError("error in get_distance_multiline_feature: %s" % err.message)
    else:
        return totLength

def get_line_buffer(inputLine, distBuff):
    """
    Returns a tuple of buffer output and buffer time."
    """
    try:
        btimeStart = time.clock()
        if gp.Describe(inputLine).ShapeType != "Polyline":
            raise Exception("input \"%s\" must be a line feature" % os.path.basename(inputLine))
        # Dissolve polyline into a single line (to generate only one line buffer).
        outLineDissolve = os.path.join("in_memory", "line_dissolve")
        gp.Dissolve_management(inputLine, outLineDissolve)
        # Create buffer around the line.
        outBuffer = os.path.join("in_memory", "line_buffer")
        gp.Buffer_analysis(outLineDissolve, outBuffer, distBuff, "FULL", "ROUND", "ALL", "")
    except Exception, err:
        raise Exception("cannot generate the line buffer: %s" % err.args)
    else:
        gert.delete_featureclass(outLineDissolve)
        btimeEnd = time.clock()
        bufferTime = btimeEnd - btimeStart
        return outBuffer, bufferTime

def select_links_as_barriers(fcLayer, roadLayer, outBuffer, distance="100 Meters"):
    """
    Select road links for conversion to point barriers.
    """
    intersectStart = time.clock()
    try:
        # Select roads within a designated distance from origin and destination (OD) locations.
        gp.SelectLayerByLocation_management(roadLayer, "WITHIN_A_DISTANCE",
                                            fcLayer, distance, "NEW_SELECTION")  # 
        # Select roads connected to previous selection.
        gp.SelectLayerByLocation_management(roadLayer, "BOUNDARY_TOUCHES",
                                            roadLayer, "", "ADD_TO_SELECTION")
        # Select roads that crossed the buffer line.
        gp.SelectLayerByLocation_management(roadLayer, "CROSSED_BY_THE_OUTLINE_OF",
                                            outBuffer, "", "ADD_TO_SELECTION")
        # Deselect roads within a designated distance from OD locations.
        gp.SelectLayerByLocation_management(roadLayer, "WITHIN_A_DISTANCE",
                                            fcLayer, distance, "REMOVE_FROM_SELECTION")
        # Deselect roads that are completely within the buffer zone.
        gp.SelectLayerByLocation_management(roadLayer, "COMPLETELY_WITHIN",
                                            outBuffer, "", "REMOVE_FROM_SELECTION")
    except:
        #raise Exception("selecting road links for conversion to point barriers not successful)
        return None
    else:
        intersectEnd = time.clock()
        intersectTime = intersectEnd - intersectStart
        return intersectTime

def get_point_barriers(fcLayer, roadLayer, inBuffer, sortField):
    """
    Returns point barriers from the intersect of the buffer outline and roads.
    """
    try:
        # Select origin and destination points.
        try:
            gert.select_odpoints3(fcLayer, sortField)
        except:
            raise
        # Select road links for conversion to point barriers.
        intersectTime = select_links_as_barriers(fcLayer, roadLayer, inBuffer)
        # Convert selected road links to point barriers
        if intersectTime:
            try:
                barrierStart = time.clock()
                #outBarriers = gert.get_featureclass_name(gp.ScratchWorkspace, "point_barriers")
                outBarriers = os.path.join("in_memory", "point_barriers")
                gp.FeatureToPoint_management(roadLayer, outBarriers, "INSIDE")
            except:
                raise
            else:
                barrierEnd = time.clock()
                barrierTime = barrierEnd - barrierStart
                return outBarriers, barrierTime
        else:
            raise Exception("cannot generate point barriers")
    except:
        raise

def get_line_barriers(inBuffer):
    """
    Returns line barriers from the intersect of buffer outline and roads.
    """
    try:
        barrierStart = time.clock()
        # Make feature layer if not.
        inBufferLayer = gert.get_layer(inBuffer)
        #outBarriers = gert.get_featureclass_name(gp.ScratchWorkspace, "line_barriers")
        outBarriers = os.path.join("in_memory", "line_barriers")
        gp.FeatureToLine_management(inBufferLayer, outBarriers)
    except:
        raise Exception("failed to create line barriers")
    else:
        barrierEnd = time.clock()
        barrierTime = barrierEnd - barrierStart
        return outBarriers, barrierTime

def get_barriers(fcLayer, roadLayer, inBuffer, sortField=None):
    """
    Returns an appropriate type of barriers for the route solver.
    """
    try:
        if float(gert.get_arcgis_version()) < 10:  # for ArcGIS 9.3.1 or earlier
            outBarriers, barrierTime = get_point_barriers(fcLayer, roadLayer, inBuffer, sortField)
        else:  # for ArcGIS 9.3.1 or earlier
            outBarriers, barrierTime = get_line_barriers(inBuffer)
    except:
        raise
    else:
        return outBarriers, barrierTime

def get_mapmatch_routes(inNetworkDataset, inStops, attrImpedance="Minutes",
                        inBarriers=None, sortField=None, getTime=False,
                        attrRestriction=" "):
    """
    Returns a tuple of network analysis layer and map-matched routes sublayer (NALayer, routesSubLayer, {solveTime}).
    {} optional
    
    The map-matched route is defined by input route endpoints and point barriers.
    Solution uses shortest path and other tools from the Network Analyst extension in ArcGIS.
    Originally developed for ArcGIS 9.3 with ArcInfo license.

    Parameters:
    @inNetworkDataset = network dataset
    @inStops = origin and destination points <- feature class or layer
    @attrImpedance = attribute impedance [Minutes, Meters] <- string
    @inBarriers = barriers <- feature class or layer
    @sortField = name of the field to sort inStops <- string
    @getTime = set to include solving time in the tuple to
                track performance [True, False] <- boolean
    @attrRestriction = list of restriction attributes to apply during analysis
    """
    solveStart = time.clock()
    # Create route layer.
    try:
        gp.MakeRouteLayer_na(inNetworkDataset, "RouteLayer", attrImpedance,
                             "USE_INPUT_ORDER", "PRESERVE_BOTH",
                             "NO_TIMEWINDOWS", "Minutes;Meters",
                             "ALLOW_UTURNS", attrRestriction, "NO_HIERARCHY",  # option to change restriction
                             "", "TRUE_LINES_WITH_MEASURES", "")
    except:
        raise
    
    # Add stops (origin and destination) to route analysis layer.
    try:
        gert.select_odpoints3(inStops, sortField)  # endpoints
        gp.AddLocations_na("RouteLayer", "Stops", inStops, "", "")
    except:
        raise
    else:  # clear previous selection
        gert.clear_selection(inStops)
    
    # Add barriers to route analysis layer.
    if inBarriers:
        # Set type of stop barriers for Network Analyst.
        shapeType = gp.Describe(inBarriers).ShapeType
        gisVersion = gert.get_arcgis_version()
        if float(gisVersion) < 10:  # for ArcGIS 9.3.1 or earlier
            if shapeType == "Point":
                typeBarriers = "Barriers"
            else:
                raise Exception("cannot add barriers, ArcGIS %s works only on point barriers" % gisVersion)
        else:  # for ArcGIS 10.0 or later
            if shapeType == "Point":
                typeBarriers = "Point Barriers"
            elif shapeType == "Polyline":
                typeBarriers = "Line Barriers"
            elif shapeType == "Polygon":
                typeBarriers = "Polygon Barriers"
            else:
                raise Exception("input barriers not a valid shape type")
        # Load barriers.
        try:
            gp.AddLocations_na("RouteLayer", typeBarriers, inBarriers, "", "")
        except:
            raise
    else:
        gp.AddMessage("\tno barriers specified: solve for shortest path based on %s" % attrImpedance.lower())
    
    # Solve for the map-matched route.
    try:
        gp.Solve_na("RouteLayer", "SKIP")
    except:
        raise
    else:
        solveEnd = time.clock()
        solveTime = solveEnd - solveStart
        NALayer, routesSubLayer = "RouteLayer", "Routes"
    
    if not getTime:
        return NALayer, routesSubLayer
    else:
        return NALayer, routesSubLayer, solveTime

def get_odpoints_xytable(routefilename):
    routefn = os.path.basename(os.path.splitext(routefilename)[0])
    fnlist = routefn.split("_")
    tblname = "%s_odpoints.txt" % ("_".join(fnlist[:(len(fnlist) - 2)]))
    xytable = os.path.join(os.path.dirname(routefilename), tblname)
    return xytable

def get_odpoints_layer(routefilename):
    xytable = get_odpoints_xytable(routefilename)
    spRef = gp.Describe(routefilename).SpatialReference
    xyevents = os.path.join("in_memory", "xyevents")
    gp.MakeXYEventLayer_management(xytable, "X", "Y", xyevents, spRef)
    return xyevents

def get_activity_codes(odpoints_layer, actfield, destfield):
    """
    Returns the activity and destination codes for each route.
    """
    rows = gp.SearchCursor(odpoints_layer)
    row = rows.Next()
    while row:
        actcode = row.getvalue(actfield)
        destcode = row.getvalue(destfield)
        break
    del rows, row
    return actcode, destcode

def get_road_from_networkdataset(networkdataset):
    roadnetwork = None
    nd = gp.Describe(networkdataset)
    edgeSources = nd.edgeSources
    edge = edgeSources.Reset()
    edge = edgeSources.Next()
    while edge:
        if edge.sourceType == "EdgeFeature":
            roadnetwork = os.path.join(os.path.dirname(nd.catalogPath), edge.Name)
            break
        else:
            pass
        edge = edgeSources.Next()
    if roadnetwork is None: raise Exception("cannot retrieve road from network dataset")
    return roadnetwork

def main(routegen, inworkspace, coordsys, inRoad, inNetworkDataset,
         buffDist, outCSVFile, fcStopLights, actfield, destfield):
    
    # Set the input workspace.
    gp.Workspace = inworkspace
    gp.AddMessage("\nWorkspace: %s" % gp.Workspace)
    
    # Set the scratch folder or temporary working directory.
    gp.ScratchWorkspace = gert.get_scratch_folder(prefix="rca_temp_")
    gp.AddMessage("Scratch workspace: %s" % gp.ScratchWorkspace)

    # Set the projected coordinate system for the road network.
    gp.SetProgressorLabel("Set the projected coordinate system for the road network ...")
    spatialRef = gp.CreateObject("spatialreference")
    spatialRef.LoadFromString(coordsys)
    gp.AddMessage("Projected coordinate system: %s" % spatialRef.Name)
    
    # Get junction layer to count intersections.
    gp.SetProgressorLabel("Get junction layer to count intersections ...")
    junction_layer = gert.get_junction_layer(inNetworkDataset)
    
    # Create road network layer.
    roadLayer = gert.get_unique_layer(inRoad)

    ########################################################################
    # Define impedance based on type of routes to be generated.
    if routegen == "Observed Route":
        withBarriers = True
    elif routegen == "Shortest Path by Distance":
        withBarriers = False
        attrImpedance = "Meters"
    elif routegen == "Shortest Path by Time":
        withBarriers = False
        attrImpedance = "Minutes"
    else:
        raise Exception("type of routes to be generated not correctly specified")
    
    # Define route restrictions based on barriers.
    if withBarriers:
        attrImpedance = "Meters"
        routeRestriction = " " # set to empty for problematic routes to work
    else:
        routeRestriction = "Oneway; TurnRestrictions"
        
    # Create and open the output CSV file object.
    varOutFile = open(outCSVFile, "wb")
    ########################################################################
    
    gp.SetProgressorLabel("List input routes for processing ...")
    routeList = []
    for inputfile in gert.all_files(gp.Workspace, patterns="*_observed_*.shp;*_alternative_*.shp"):
        routeList.append(inputfile)
        #gp.AddMessage(inputfile)
    
    # Determine the number of input routes.    
    inputCount = len(routeList)
    gp.AddMessage("Total number of input routes to process: %i" % inputCount)
    
    ########################################################################
    # Process each route to extract attribute information.
    gp.SetProgressor("step", "Running route choice analysis tool ...", 0, inputCount, 1)
    
    withHeader = True
    for route in routeList:
        
        ## Used to select subsets of routes for debugging purposes only.
        #if os.path.splitext(os.path.basename(route))[0] != "14695_20070414_07_alternative_6349017":
        #    gp.AddMessage(os.path.splitext(os.path.basename(route))[0])
        #    gp.SetProgressorPosition()
        #    continue

        startTime = time.clock()  # initialize timer to check the running time
        
        gp.AddMessage("\nProcessing input route: %s..." % route)
        route_layer = gert.get_unique_layer(route)
        
        # Extract origin and destination points from route input.
        try:
            xyevents = get_odpoints_layer(route)  # read OD coordinates from text file
            odpoints = os.path.join("in_memory", "odpoints")
            #odpoints = gert.get_featureclass_name(gp.ScratchWorkspace, "odpoints")  # for validation
            gp.CopyFeatures_management(xyevents, odpoints)
        except:
            raise
        else:
            gert.delete_featureclass(xyevents)
            actCode, destCode = get_activity_codes(odpoints, actfield, destfield)
            #gp.AddMessage("actcode: %i, destcode: %i" % (actCode, destCode))
        
        # Create feature layer of origin and destination points (odpoints).
        try:
            odpoints_layer = gert.get_unique_layer(odpoints)
        except Exception, err:
            gp.AddError("cannot create layer for %s: %s" % (route, err.args))
        
        # Generate the map-matched route.
        gp.SetProgressorLabel("Retrieve the route layer by map-matching...")
        if withBarriers:
            outBuffer, bufferTime = get_line_buffer(route_layer, buffDist)
            #gp.AddMessage("\tcreated route buffer...")
            
            outBarriers, barrierTime = get_barriers(odpoints_layer, roadLayer, outBuffer, sortField=None)
            #gp.AddMessage("\tcreated route barriers...")
        else:
            outBuffer, outBarriers = None, None
            
        try:
            outNALayer, naRouteSubLayer, solveTime = get_mapmatch_routes(inNetworkDataset, odpoints_layer, attrImpedance,
                                                               inBarriers=outBarriers, sortField=None, getTime=True,
                                                               attrRestriction=routeRestriction)
            #gp.AddMessage("\tgenerated map-matched route...")
        except Exception, err:
            gp.AddError("failed to generate map-matched route: %s" % err.args)
            gp.SetProgressorPosition()
            continue
        
        # Calculate length of GPS trajectory (line).
        #tracLength = get_distance_multiline_feature(route_layer, spatialRef)
        #gp.AddMessage("\nLength of GPS trajectory: %.1f meters" % tracLength)

        ########################################################################
        # Generate NALayer-based variables (green tool - network information)
        gp.SetProgressorLabel("Generate variables based on Network Analyst (NA) layer...")
        #gp.AddMessage("\nStarted processing GREEN tool variables...")
        
        # Get lat, lon coordinates for origin and destination points.
        origLat, origLon, destLat, destLon = get_coordinates(odpoints_layer)
        #gp.AddMessage("Extracted lat, lon coordinates:\n\torigin: %s, %s\n\tdestination: %s, %s" % (origLat, origLon, destLat, destLon))

        # Get straightline distance in meters.
        crowDist = gert.get_point_distance2(origLat, origLon, destLat, destLon)
        #gp.AddMessage("Straightline distance between origin and destination: %.1f meters" % crowDist)
        
        # Count the number of turns.
        p = ParserDirectionsXML2(outNALayer)
        leftTurns = p.countLeftTurn
        rightTurns = p.countRightTurn
        sharpLeft = p.countSharpLeft
        sharpRight = p.countSharpRight
        totalTurns = p.countAllTurns
        #gp.AddMessage("Extracted number of turns:\n\tleft turns: %s\n\tright turns: %s\n\tsharp left: %s\n\tsharp right: %s\n\ttotal turns: %s"
        #              % (leftTurns, rightTurns, sharpLeft, sharpRight, totalTurns))
        
        # Get number of route segments, distance, time, and longest segment.
        numSeg, uniqSeg = p.count_segments(), p.count_unique_segments()
        longLegName, longLegDist = p.get_longleg_attribute("name"), p.get_longleg_attribute("distance")
        totTime, totDist = p.get_total_time(), p.get_total_distance()
        #gp.AddMessage("Extracted following parameters from directions file:")
        #gp.AddMessage("\tlongest leg name: %s\n\tlongest leg distance: %.1f meters" % (longLegName, longLegDist))
        #gp.AddMessage("\tnumber of segments: %s\n\tnumber of unique segments: %s" % (numSeg, uniqSeg))
        #gp.AddMessage("\ttotal route length: %.1f meters" % totDist)
        #gp.AddMessage("\ttotal route time: %.1f minutes" % totTime)

        # Calculate route directness index (loop factor).
        try:
            ndxRouteDirect = totDist / crowDist  # route distance over straightline distance
        except ZeroDivisionError:
            ndxRouteDirect = 0  # very short segment
        except:
            raise
        #gp.AddMessage("Route directness index: %.1f" % ndxRouteDirect)
        
        ########################################################################
        # Generate road network-based variables (red tool - attribute and spatial information)
        gp.SetProgressorLabel("Generate variables based on road network attribute information...")
        #gp.AddMessage("\nStarted processing RED tool variables...")
        
        # Get dictionary of route attributes by segment.
        A = get_attributes(route_layer, spatref=spatialRef)
        #gp.AddMessage("\nExtracted route segment attributes to a dictionary.")
        
        # Total distance and time for the entire route.
        distRdList = [A[k]["distance"] for k in A.keys()]
        timeRdList = [A[k]["time"] for k in A.keys()]
        totRdDist = sum(distRdList)
        totRdTime = sum(timeRdList)
        #gp.AddMessage("\nExtracted distance and time for the entire route:\n\ttotal distance: %.1f meters\n\ttotal time: %.1f minutes" %
        #              (totRdDist, totRdTime))
        
        # Speed statistics (km/h).
        spdRdList = [A[k]["speed"] for k in A.keys()]
        splmt_min = min(spdRdList)  # minimum speed limit
        splmt_max = max(spdRdList)  # maximum speed limit
        splmt_mean = mean(spdRdList)  # mean speed limit
        splmt_std = std(spdRdList)  # standard deviation speed limit
        splmt_count = len(spdRdList)  # count speed limit
        #gp.AddMessage("Speed descriptive statistics:\n\tmin: %.2f\n\tmax: %.2f\n\tmean: %.2f\n\tstd: %.2f\n\tcount: %i" %
        #              (splmt_min, splmt_max, splmt_mean, splmt_std, splmt_count))
        
        # Speed percentiles from 10th to 90th
        sp_10 = percentile(spdRdList, 10)  # 10th percentile
        sp_20 = percentile(spdRdList, 20)  # 20th percentile
        sp_30 = percentile(spdRdList, 30)  # 30th percentile
        sp_40 = percentile(spdRdList, 40)  # 40th percentile
        sp_50 = percentile(spdRdList, 50)  # 50th percentile
        sp_60 = percentile(spdRdList, 60)  # 60th percentile
        sp_70 = percentile(spdRdList, 70)  # 70th percentile
        sp_80 = percentile(spdRdList, 80)  # 80th percentile
        sp_90 = percentile(spdRdList, 90)  # 90th percentile
        #gp.AddMessage("Speed percentiles:\n\t10th percentile: %.1f\n\t20th percentile: %.1f\n\t30th "\
        #              "percentile: %.1f\n\t40th percentile: %.1f\n\t50th percentile: %.1f\n\t60th percentile: %.1f\n\t70th "\
        #              "percentile: %.1f\n\t80th percentile: %.1f\n\t90th percentile: %.1f" % (sp_10, sp_20, sp_30, sp_40, sp_50, sp_60, sp_70, sp_80, sp_90))
        
        # Carto (cartographic road classification) = {1:'expressway', 2:'primary highway',
        # 3:'secondary highway', 4:'major road', 5:'local road'}
        carto1_pdist = sum([A[k]["distance"] for k in A.keys() if A[k]["rdclass"] == 1])/totRdDist  # percent of route distance in carto 1
        carto2_pdist = sum([A[k]["distance"] for k in A.keys() if A[k]["rdclass"] == 2])/totRdDist  # percent of route distance in carto 2
        carto3_pdist = sum([A[k]["distance"] for k in A.keys() if A[k]["rdclass"] == 3])/totRdDist  # percent of route distance in carto 3
        carto4_pdist = sum([A[k]["distance"] for k in A.keys() if A[k]["rdclass"] == 4])/totRdDist  # percent of route distance in carto 4
        carto5_pdist = sum([A[k]["distance"] for k in A.keys() if A[k]["rdclass"] == 5])/totRdDist  # percent of route distance in carto 5
        #gp.AddMessage("Percentage distribution of route distance by carto class:\n\tcarto1_pdist: %.2f\n\t"\
        #              "carto2_pdist: %.2f\n\tcarto3_pdist: %.2f\n\tcarto4_pdist: %.2f\n\tcarto5_pdist: %.2f" %
        #              (carto1_pdist, carto2_pdist, carto3_pdist, carto4_pdist, carto5_pdist))

        carto1_ptime = sum([A[k]["time"] for k in A.keys() if A[k]["rdclass"] == 1])/totRdTime  # percent of route duration in carto 1
        carto2_ptime = sum([A[k]["time"] for k in A.keys() if A[k]["rdclass"] == 2])/totRdTime  # percent of route duration in carto 2
        carto3_ptime = sum([A[k]["time"] for k in A.keys() if A[k]["rdclass"] == 3])/totRdTime  # percent of route duration in carto 3
        carto4_ptime = sum([A[k]["time"] for k in A.keys() if A[k]["rdclass"] == 4])/totRdTime  # percent of route duration in carto 4
        carto5_ptime = sum([A[k]["time"] for k in A.keys() if A[k]["rdclass"] == 5])/totRdTime  # percent of route duration in carto 5
        #gp.AddMessage("Percentage distribution of route time by carto class:\n\tcarto1_ptime: %.2f\n\t"\
        #              "carto2_ptime: %.2f\n\tcarto3_ptime: %.2f\n\tcarto4_ptime: %.2f\n\tcarto5_ptime: %.2f" %
        #              (carto1_ptime, carto2_ptime, carto3_ptime, carto4_ptime, carto5_ptime))
        
        # Total distance and time for the entire route summarized by road name.
        B = summarize_attrib_by_rdname(A)
        distGrpRdList = [B[k]["distance"] for k in B.keys()]
        timeGrpRdList = [B[k]["time"] for k in B.keys()]
        totGrpRdDist = sum(distGrpRdList)
        totGrpRdTime = sum(timeGrpRdList)
        
        # Longest route segment based on distance.
        dleg = int([k for k in B.keys() if B[k]["distance"] == max(distGrpRdList)][0])
        dleg_name = B[dleg]["rdname"]  # street name of longest route segment based on distance
        dleg_carto = int(B[dleg]["rdclass"])  # carto class [1, 2, 3, 4, 5] of longest route segment based on distance
        dleg_dist = B[dleg]["distance"]  # distance (in meters) of longest route segment based on distance
        dleg_time = B[dleg]["time"]  # duration (in minutes) of longest route segment based on distance
        #gp.AddMessage("Longest route segment based on distance:\n\tdleg_name: %s\n\tdleg_"\
        #              "carto: %i\n\tdleg_dist: %.1f meters\n\tdleg_time: %.1f minutes" % (dleg_name, dleg_carto, dleg_dist, dleg_time))
        
        dleg_carto1_share = carto_share(1, dleg_carto, B[dleg]["distance"], totGrpRdDist)  # percent of route distance in dleg_carto class 1
        dleg_carto2_share = carto_share(2, dleg_carto, B[dleg]["distance"], totGrpRdDist)  # percent of route distance in dleg_carto class 2
        dleg_carto3_share = carto_share(3, dleg_carto, B[dleg]["distance"], totGrpRdDist)  # percent of route distance in dleg_carto class 3
        dleg_carto4_share = carto_share(4, dleg_carto, B[dleg]["distance"], totGrpRdDist)  # percent of route distance in dleg_carto class 4
        dleg_carto5_share = carto_share(5, dleg_carto, B[dleg]["distance"], totGrpRdDist)  # percent of route distance in dleg_carto class 5
        #gp.AddMessage("Percentage distribution of route distance within longest route segment by carto class:\n\tdleg_carto1_share: %.2f\n\t"\
        #              "dleg_carto2_share: %.2f\n\tdleg_carto3_share: %.2f\n\tdleg_carto4_share %.2f\n\tdleg_carto5_share: %.2f" %
        #              (dleg_carto1_share, dleg_carto2_share, dleg_carto3_share, dleg_carto4_share, dleg_carto5_share))

        # Longest route segment based on time.
        tleg = int([k for k in B.keys() if B[k]["time"] == max(timeGrpRdList)][0])
        tleg_name = B[tleg]["rdname"]  # street name of longest route segment based on time
        tleg_carto = int(B[tleg]["rdclass"])  # carto class [1, 2, 3, 4, 5] of longest route segment based on time
        tleg_dist = B[tleg]["distance"]  # distance (in meters) of longest route segment based on time
        tleg_time = B[tleg]["time"]  # duration (in minutes) of longest route segment based on time
        #gp.AddMessage("Longest route segment based on time:\n\ttleg_name: %s\n\ttleg_"\
        #              "carto: %i\n\ttleg_dist: %.1f meters\n\ttleg_time: %.1f minutes" % (tleg_name, tleg_carto, tleg_dist, tleg_time))

        tleg_carto1_share = carto_share(1, tleg_carto, B[tleg]["time"], totGrpRdTime)  # percent of route duration in tleg_carto class 1
        tleg_carto2_share = carto_share(2, tleg_carto, B[tleg]["time"], totGrpRdTime)  # percent of route duration in tleg_carto class 2
        tleg_carto3_share = carto_share(3, tleg_carto, B[tleg]["time"], totGrpRdTime)  # percent of route duration in tleg_carto class 3
        tleg_carto4_share = carto_share(4, tleg_carto, B[tleg]["time"], totGrpRdTime)  # percent of route duration in tleg_carto class 4
        tleg_carto5_share = carto_share(5, tleg_carto, B[tleg]["time"], totGrpRdTime)  # percent of route duration in tleg_carto class 5
        #gp.AddMessage("Percentage distribution of route distance within longest route segment by carto class:\n\ttleg_carto1_share: %.2f\n\t"\
        #              "tleg_carto2_share: %.2f\n\ttleg_carto3_share: %.2f\n\ttleg_carto4_share %.2f\n\ttleg_carto5_share: %.2f" %
        #              (tleg_carto1_share, tleg_carto2_share, tleg_carto3_share, tleg_carto4_share, tleg_carto5_share))
        
        # Count the number of stop lights, intersections and average valence value.
        if fcStopLights:
            numStopL = count_stops(fcStopLights, naRouteSubLayer, searchDist="50 Meters")  # number of stop lights
        else:
            numStopL = "NULL"  # stop lights not available for the analysis
        
        vtxFeature = None
        #try:  # generate vertices from route segments
        #    vtxFeature = os.path.join("in_memory", "route_vertices")  # route vertices
        #    gp.FeatureVerticesToPoints_management(route_layer, vtxFeature, "BOTH_ENDS")
        #except:
        #    raise
        #else:
        #    xingD = get_intersections(vtxFeature, roadLayer)  # dictionary of intersections
        try:  # number of intersections (crossings)
            #numXing = len(xingD)
            numXing = count_stops(junction_layer, naRouteSubLayer)
        except TypeError:  # get_intersections() returns None
            numXing = 0
        try:  # route distance per intersection (in meters)
            distPerXing = totRdDist/numXing
        except ZeroDivisionError:
            distPerXing = 0
        #if numXing:
        #    meanValence = mean([xingD[k]["valence"] for k in xingD.keys()]) # average valence (average number of adjacent links per node/junction)
        #else:
        #    meanValence = 0
        #gp.AddMessage("\nExtracted number of stop lights, intersections and valence "\
        #              "value:\n\tnumber of stop lights: %i\n\tnumber of "\
        #              "intersections: %i\n\tdistance per intersection: %.1f meters\n\taverage valence value: %.1f" %
        #              (numStopL, numXing, distPerXing, meanValence))
        
        ########################################################################
        # Write extracted variables to CSV file.
        gp.SetProgressorLabel("Write variables to CSV file...")
        routeID = os.path.basename(route).split(".")[0]
        respID = os.path.basename(route).split("_")[0]

        varNames = [
            ["routeID"],  # respondent ID, date, episode number to identify route
            ["respID"],  # respondent ID
            ["actCode"],  # activity code
            ["destCode"],  # activity code at the destination
            ["origLat", "origLon", "destLat", "destLon"],  # lat, lon (GREEN tool vars)
            ["crowDist"],  # straightline distance
            ["leftTurns", "rightTurns", "sharpLeft", "sharpRight", "totalTurns"],  # turns
            ["longLegName", "longLegDist"],  # longest leg based on distance from network analysis layer
            ["numSeg", "uniqSeg"],  # number of segments, unique segments
            ["totDist", "totTime"],  # total distance and time based on network analysis layer
            ["ndxRouteDirect"],  # route distance over straightline distance (totDist / crowDist)
            ["totRdDist", "totRdTime"],  # total distance and time based on input road network
            ["splmt_min", "splmt_max", "splmt_mean", "splmt_std", "splmt_count"],  # speed statistics (km/h)
            ["sp_10", "sp_20", "sp_30", "sp_40", "sp_50", "sp_60", "sp_70", "sp_80", "sp_90"],  # speed percentiles
            ["carto1_pdist", "carto2_pdist", "carto3_pdist", "carto4_pdist", "carto5_pdist"],  # road class distribution by distance
            ["carto1_ptime", "carto2_ptime", "carto3_ptime", "carto4_ptime", "carto5_ptime"],  # road class distribution by time
            ["dleg_name", "dleg_carto", "dleg_dist", "dleg_time"],  # longest leg based on distance
            ["dleg_carto1_share", "dleg_carto2_share", "dleg_carto3_share", "dleg_carto4_share", "dleg_carto5_share"],  # longest leg distribution by distance
            ["tleg_name", "tleg_carto", "tleg_dist", "tleg_time"],  # longest leg based on time
            ["tleg_carto1_share", "tleg_carto2_share", "tleg_carto3_share", "tleg_carto4_share", "tleg_carto5_share"],  # longest leg distribution by time
            ["numStopL"],  # number of stop lights
            ["numXing", "distPerXing"]  # number of intersections, distance per intersection
            #["meanValence"]  # average valence value (average number of adjacent links per node/junction)
            ]
        
        if withHeader:
            headerList, headerListToWrite = [], []
            for varName in varNames:
                for var in varName:
                    headerList.append(var)
            headerListToWrite.extend(headerList)  # list of fieldnames (header)
            headerListToWrite.append("".join([headerListToWrite.pop(), os.linesep]))  # add line separator
            headerLine = ",".join(headerListToWrite)  # convert to CSV format
            varOutFile.writelines(headerLine)  # write header to output CSV file
            varOutFile.flush()
            del headerListToWrite, headerLine
            withHeader = False
        varList = [str(eval(var)) for var in headerList]  # retrieve value for each fieldname (variable)
        varList.append("".join([varList.pop(), os.linesep]))  # add line separator
        varLine = ",".join(varList)  # convert to CSV format
        varOutFile.writelines(varLine)  # write field values to output CSV file
        varOutFile.flush()
        
        # Delete intermediate data then proceed to next route.
        gert.delete_featureclass(route_layer, odpoints_layer, outNALayer, outBuffer, outBarriers, vtxFeature)
        gp.SetProgressorPosition()

    # Close the output CSV file object.
    varOutFile.close()
    
    # Remove temporary feature classes and scratch folder.
    try:
        gert.delete_featureclass(roadLayer, gp.ScratchWorkspace)
        gp.AddMessage("\nDeleted temporary files and scratch folder.")
    except:
        raise

if __name__ == '__main__':
    
    # User-defined parameters.
    routegen = gp.GetParameterAsText(0)  # type of routes to be generated
    inworkspace = gp.GetParameterAsText(1)  # input workspace containing route choice sets
    inNetworkDataset = gp.GetParameterAsText(2)  # network dataset (e.g., "G:\Temp\network_database\NAD83\CanMapRL\CAN_GD.gdb\CAN_ND\CAN_ND")
    coordsys = gp.GetParameterAsText(3)  # projected coordinate system (e.g., NAD 1983 UTM Zone 20N for STAR datasets)
    fcStopLights = gp.GetParameterAsText(4)  # stop lights (e.g., r"G:\Temp\rca\NS_Traffic_Lights.shp")
    outCSVFile = gp.GetParameterAsText(5)  # output CSV file
    
    # Hard-coded parameters.
    inRoad = get_road_from_networkdataset(inNetworkDataset)  # road network (used to generate route barriers)
    buffDist = "10 Meters"  # buffer distance (known distortions occur at 50 meters or more)
    actfield = "ACTCODE"  # fieldname for activity code
    destfield = "DESTCODE"  # fieldname for activity code at the destination
    
    # Get the folder for metadata geoprocessing history.
    gis_version = gp.GetInstallInfo()["Version"]
    gplogfolder = gert.get_folder(os.getenv("APPDATA"), ("Desktop%s;ArcToolbox;History" % gis_version))
    
    # List metadata geoprocessing history files that should not be deleted.
    #donot_remove_list = gert.list_files(gplogfolder, file_patterns="*.xml")
    donot_remove_list = []  # clear up geoprocessing history folder
    
    try:
        main(routegen, inworkspace, coordsys, inRoad, inNetworkDataset,
             buffDist, outCSVFile, fcStopLights, actfield, destfield)
    except:
        gp.AddError(traceback.format_exc())  # traceback info
    finally:
        gert.delete_files(gplogfolder, donot_remove_list, file_patterns="*.xml")  # delete metadata geoprocessing history
        gp.AddMessage("Deleted metadata geoprocessing history.")
        del gp; sys.exit()  # make sure all files are released (unlocked)
    